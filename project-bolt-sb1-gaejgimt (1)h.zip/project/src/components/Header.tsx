import type { TabId } from '@/types';

interface HeaderProps {
  activeTab: TabId;
  onOpenProfile: () => void;
  onSearch: () => void;
}

const TITLES: Record<TabId, { title: string; subtitle: string }> = {
  home: { title: 'trivive', subtitle: 'Learn. Earn. Thrive.' },
  explore: { title: 'Finance', subtitle: 'ALLEN Currency & balance' },
  create: { title: 'Campus Canteen', subtitle: 'Fuel for growth, focus & strength' },
  activity: { title: 'Miscellaneous', subtitle: 'Complaints & campus issues' },
  profile: { title: 'Health Tracker', subtitle: 'Relax, learn, stay well' },
};

export default function Header({ activeTab, onOpenProfile }: HeaderProps) {
  const { title, subtitle } = TITLES[activeTab];

  return (
    <header className="sticky top-0 z-30 bg-white/80 backdrop-blur-xl border-b border-slate-200/60">
      <div className="px-5 pt-4 pb-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-600 to-sky-500 flex items-center justify-center shadow-lg shadow-blue-500/20">
              <span className="text-white font-bold text-lg">T</span>
            </div>
            <div>
              <h1 className="text-lg font-bold text-slate-900 leading-tight">{title}</h1>
              <p className="text-xs text-slate-500 leading-tight">{subtitle}</p>
            </div>
          </div>

          <button
            onClick={onOpenProfile}
            className="w-10 h-10 rounded-full bg-gradient-to-br from-amber-400 to-orange-500 flex items-center justify-center text-white font-semibold text-sm shadow-md shadow-orange-500/30 ring-2 ring-white active:scale-90 transition-all"
            aria-label="Open profile"
          >
            A
          </button>
        </div>
      </div>
    </header>
  );
}
