import type { LessonsTab, WalletTab } from '@/types';

interface SubNavProps {
  tabs: { id: string; label: string }[];
  activeTab: string;
  onChange: (tab: string) => void;
  accent: 'emerald' | 'blue';
}

export default function SubNav({ tabs, activeTab, onChange, accent }: SubNavProps) {
  const activeColor = accent === 'emerald' ? 'text-emerald-600' : 'text-blue-600';
  const inactiveColor = 'text-slate-400';
  const barColor = accent === 'emerald' ? 'bg-emerald-500' : 'bg-blue-500';

  return (
    <div className="sticky top-[68px] z-20 bg-white/80 backdrop-blur-xl border-b border-slate-200/60">
      <div className="flex items-center justify-around px-2">
        {tabs.map((tab) => {
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => onChange(tab.id)}
              className="relative px-4 py-2.5 transition-all"
            >
              <span className={`text-sm font-semibold ${isActive ? activeColor : inactiveColor}`}>
                {tab.label}
              </span>
              {isActive && (
                <span className={`absolute bottom-0 left-1/2 -translate-x-1/2 w-8 h-0.5 rounded-full ${barColor}`} />
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
}

export const LESSONS_TABS: { id: LessonsTab; label: string }[] = [
  { id: 'home', label: 'Home' },
  { id: 'dashboard', label: 'Dashboard' },
  { id: 'progress', label: 'Progress' },
  { id: 'quiz', label: 'Quiz' },
];

export const WALLET_TABS: { id: WalletTab; label: string }[] = [
  { id: 'studies', label: 'Studies' },
  { id: 'food', label: 'Food' },
];
