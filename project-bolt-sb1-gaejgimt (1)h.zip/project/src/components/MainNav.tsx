import { BookOpen, Wallet } from 'lucide-react';
import type { MainSection } from '@/types';

interface MainNavProps {
  activeSection: MainSection;
  onChange: (section: MainSection) => void;
}

export default function MainNav({ activeSection, onChange }: MainNavProps) {
  return (
    <nav className="fixed bottom-0 left-0 right-0 z-30 bg-white/90 backdrop-blur-xl border-t border-slate-200/60 pb-[env(safe-area-inset-bottom)]">
      <div className="flex items-stretch justify-center gap-8 px-4 pt-2.5 pb-2">
        <button
          onClick={() => onChange('lessons')}
          className="flex flex-col items-center gap-1 px-6 active:scale-90 transition-transform"
          aria-label="Lessons"
        >
          <BookOpen
            size={24}
            strokeWidth={activeSection === 'lessons' ? 2.5 : 2}
            className={activeSection === 'lessons' ? 'text-emerald-600' : 'text-slate-400'}
          />
          <span className={`text-[11px] font-semibold ${activeSection === 'lessons' ? 'text-emerald-600' : 'text-slate-400'}`}>
            Lessons
          </span>
        </button>
        <button
          onClick={() => onChange('wallet')}
          className="flex flex-col items-center gap-1 px-6 active:scale-90 transition-transform"
          aria-label="Wallet"
        >
          <Wallet
            size={24}
            strokeWidth={activeSection === 'wallet' ? 2.5 : 2}
            className={activeSection === 'wallet' ? 'text-blue-600' : 'text-slate-400'}
          />
          <span className={`text-[11px] font-semibold ${activeSection === 'wallet' ? 'text-blue-600' : 'text-slate-400'}`}>
            Wallet
          </span>
        </button>
      </div>
    </nav>
  );
}
