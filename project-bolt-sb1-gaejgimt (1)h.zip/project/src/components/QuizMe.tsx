import { useState, useMemo, useCallback } from 'react';
import {
  X,
  ChevronRight,
  CheckCircle2,
  XCircle,
  Award,
  RefreshCw,
  Loader2,
  Brain,
  Sparkles,
  BookOpen,
  TrendingUp,
  RotateCcw,
} from 'lucide-react';
import { QUIZ_TOPICS, type Difficulty, type QuizQuestion } from '@/data/quizTopics';

interface QuizMeProps {
  onClose: () => void;
}

type Phase = 'setup' | 'quiz' | 'result';

const DIFFICULTIES: { id: Difficulty; label: string; color: string; bg: string }[] = [
  { id: 'easy', label: 'Easy', color: 'text-emerald-600', bg: 'from-emerald-500 to-teal-500' },
  { id: 'medium', label: 'Medium', color: 'text-amber-600', bg: 'from-amber-500 to-orange-500' },
  { id: 'hard', label: 'Hard', color: 'text-rose-600', bg: 'from-rose-500 to-pink-500' },
];

const QUIZ_LENGTH = 5;

interface QuizResult {
  question: QuizQuestion;
  selectedIndex: number;
  correct: boolean;
}

function shuffle<T>(arr: T[]): T[] {
  const copy = [...arr];
  for (let i = copy.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [copy[i], copy[j]] = [copy[j], copy[i]];
  }
  return copy;
}

export default function QuizMe({ onClose }: QuizMeProps) {
  const [phase, setPhase] = useState<Phase>('setup');
  const [topicId, setTopicId] = useState<string>('');
  const [difficulty, setDifficulty] = useState<Difficulty>('medium');
  const [generating, setGenerating] = useState(false);
  const [questions, setQuestions] = useState<QuizQuestion[]>([]);
  const [currentQ, setCurrentQ] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [showResult, setShowResult] = useState(false);
  const [results, setResults] = useState<QuizResult[]>([]);

  const topic = QUIZ_TOPICS.find((t) => t.id === topicId);

  const handleGenerate = useCallback(() => {
    if (!topic) return;
    setGenerating(true);
    setTimeout(() => {
      const filtered = topic.questions.filter((q) => {
        if (difficulty === 'easy') return q.difficulty === 'easy' || q.difficulty === 'medium';
        if (difficulty === 'medium') return q.difficulty !== 'hard' || true;
        return q.difficulty === 'medium' || q.difficulty === 'hard';
      });
      const pool = filtered.length >= QUIZ_LENGTH ? filtered : topic.questions;
      const picked = shuffle(pool).slice(0, Math.min(QUIZ_LENGTH, pool.length));
      setQuestions(picked);
      setCurrentQ(0);
      setSelectedAnswer(null);
      setShowResult(false);
      setResults([]);
      setGenerating(false);
      setPhase('quiz');
    }, 600);
  }, [topic, difficulty]);

  const handleAnswer = useCallback((idx: number) => {
    if (showResult) return;
    setSelectedAnswer(idx);
    setShowResult(true);
  }, [showResult]);

  const handleNext = useCallback(() => {
    if (selectedAnswer === null) return;
    const q = questions[currentQ];
    const isCorrect = selectedAnswer === q.correctIndex;
    const newResults = [...results, { question: q, selectedIndex: selectedAnswer, correct: isCorrect }];
    setResults(newResults);

    if (currentQ + 1 < questions.length) {
      setCurrentQ(currentQ + 1);
      setSelectedAnswer(null);
      setShowResult(false);
    } else {
      setPhase('result');
    }
  }, [selectedAnswer, currentQ, questions, results]);

  const handleRestart = useCallback(() => {
    setPhase('setup');
    setTopicId('');
    setQuestions([]);
    setCurrentQ(0);
    setSelectedAnswer(null);
    setShowResult(false);
    setResults([]);
  }, []);

  const score = useMemo(
    () => (results.length > 0 ? Math.round((results.filter((r) => r.correct).length / results.length) * 100) : 0),
    [results],
  );

  const wrongQuestions = useMemo(() => results.filter((r) => !r.correct), [results]);

  // ---- Setup phase ----
  if (phase === 'setup') {
    return (
      <div className="absolute inset-0 z-50 bg-slate-50 flex flex-col animate-fade-in">
        <header className="sticky top-0 z-10 bg-white/80 backdrop-blur-xl border-b border-slate-200/60">
          <div className="px-5 pt-4 pb-3 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-emerald-600 to-teal-500 flex items-center justify-center shadow-md shadow-emerald-500/20">
                <Brain size={18} className="text-white" />
              </div>
              <div>
                <h1 className="text-lg font-bold text-slate-900 leading-tight">Quiz Me</h1>
                <p className="text-xs text-slate-500 leading-tight">Test yourself on any topic</p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="w-10 h-10 rounded-full flex items-center justify-center text-slate-600 hover:bg-slate-100 active:scale-90 transition-all"
              aria-label="Close"
            >
              <X size={20} strokeWidth={2.2} />
            </button>
          </div>
        </header>

        <main className="flex-1 overflow-y-auto pb-8 no-scrollbar">
          <div className="px-5 py-4 space-y-5">
            {/* Topic input */}
            <div>
              <h3 className="text-sm font-bold text-slate-700 mb-2">What do you want to learn?</h3>
              <input
                type="text"
                value={topicId ? topic?.label ?? '' : ''}
                onChange={() => {}}
                placeholder="Type a topic or pick one below"
                className="hidden"
              />
              <div className="flex flex-wrap gap-2">
                {QUIZ_TOPICS.map((t) => {
                  const isActive = topicId === t.id;
                  return (
                    <button
                      key={t.id}
                      onClick={() => setTopicId(t.id)}
                      className={`px-3.5 py-2 rounded-xl text-sm font-semibold transition-all active:scale-95 ${
                        isActive
                          ? 'bg-gradient-to-br from-emerald-600 to-teal-600 text-white shadow-lg shadow-emerald-500/20'
                          : 'bg-white text-slate-600 border border-slate-200'
                      }`}
                    >
                      {t.label}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Difficulty */}
            <div>
              <h3 className="text-sm font-bold text-slate-700 mb-2">Choose difficulty</h3>
              <div className="flex gap-2">
                {DIFFICULTIES.map((d) => {
                  const isActive = difficulty === d.id;
                  return (
                    <button
                      key={d.id}
                      onClick={() => setDifficulty(d.id)}
                      className={`flex-1 py-3 rounded-2xl font-semibold text-sm transition-all active:scale-95 ${
                        isActive
                          ? `bg-gradient-to-br ${d.bg} text-white shadow-lg`
                          : 'bg-white text-slate-600 border border-slate-200'
                      }`}
                    >
                      {d.label}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Generate button */}
            <button
              onClick={handleGenerate}
              disabled={!topicId || generating}
              className={`w-full py-3.5 rounded-2xl font-semibold text-sm flex items-center justify-center gap-2 transition-all ${
                topicId && !generating
                  ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-500/25 active:scale-[0.98]'
                  : 'bg-slate-200 text-slate-400'
              }`}
            >
              {generating ? (
                <>
                  <Loader2 size={16} className="animate-spin" /> Generating Quiz…
                </>
              ) : (
                <>
                  <Sparkles size={16} /> Generate Quiz
                </>
              )}
            </button>

            <div className="flex items-center gap-1.5 text-[11px] text-slate-400 justify-center">
              <BookOpen size={12} /> {QUIZ_LENGTH} questions · instant feedback
            </div>
          </div>
        </main>
      </div>
    );
  }

  // ---- Quiz phase ----
  if (phase === 'quiz' && questions.length > 0) {
    const q = questions[currentQ];
    return (
      <div className="absolute inset-0 z-50 bg-slate-50 flex flex-col animate-fade-in">
        <header className="sticky top-0 z-10 bg-white/80 backdrop-blur-xl border-b border-slate-200/60">
          <div className="px-5 pt-4 pb-3 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-emerald-600 to-teal-500 flex items-center justify-center shadow-md shadow-emerald-500/20">
                <Brain size={18} className="text-white" />
              </div>
              <div>
                <h1 className="text-lg font-bold text-slate-900 leading-tight">Quiz Me</h1>
                <p className="text-xs text-slate-500 leading-tight">{topic?.label} · {difficulty}</p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="w-10 h-10 rounded-full flex items-center justify-center text-slate-600 hover:bg-slate-100 active:scale-90 transition-all"
              aria-label="Close"
            >
              <X size={20} strokeWidth={2.2} />
            </button>
          </div>
        </header>

        <main className="flex-1 overflow-y-auto pb-8 no-scrollbar">
          <div className="px-5 py-4 space-y-5">
            {/* Progress bar */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-semibold text-slate-500">
                  Question {currentQ + 1} of {questions.length}
                </span>
                <span className="text-[11px] text-slate-400 capitalize">{q.difficulty}</span>
              </div>
              <div className="h-1.5 rounded-full bg-slate-100 overflow-hidden">
                <div
                  className="h-full rounded-full bg-emerald-500 transition-all"
                  style={{ width: `${(currentQ / questions.length) * 100}%` }}
                />
              </div>
            </div>

            {/* Question */}
            <div className="bg-white rounded-2xl p-5 border border-slate-100 shadow-sm animate-fade-in">
              <p className="text-base font-semibold text-slate-800 leading-snug">{q.question}</p>
            </div>

            {/* Options */}
            <div className="space-y-2.5">
              {q.options.map((opt, i) => {
                const isCorrect = i === q.correctIndex;
                const isSelected = selectedAnswer === i;
                let style = 'border-slate-100 bg-white text-slate-700';
                if (showResult && isCorrect) {
                  style = 'border-emerald-500 bg-emerald-50 text-emerald-700';
                } else if (showResult && isSelected && !isCorrect) {
                  style = 'border-rose-500 bg-rose-50 text-rose-700';
                }
                return (
                  <button
                    key={i}
                    onClick={() => handleAnswer(i)}
                    disabled={showResult}
                    className={`w-full flex items-center gap-3 p-3.5 rounded-2xl border transition-all text-left ${style} ${
                      !showResult ? 'active:scale-[0.98]' : ''
                    }`}
                  >
                    <span
                      className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0 ${
                        showResult && isCorrect
                          ? 'bg-emerald-500 text-white'
                          : showResult && isSelected && !isCorrect
                          ? 'bg-rose-500 text-white'
                          : 'bg-slate-100 text-slate-500'
                      }`}
                    >
                      {String.fromCharCode(65 + i)}
                    </span>
                    <span className="text-sm font-medium flex-1">{opt}</span>
                    {showResult && isCorrect && <CheckCircle2 size={18} className="text-emerald-600" />}
                    {showResult && isSelected && !isCorrect && <XCircle size={18} className="text-rose-600" />}
                  </button>
                );
              })}
            </div>

            {/* Explanation */}
            {showResult && (
              <div className="animate-fade-in bg-blue-50 rounded-2xl p-4 border border-blue-100">
                <div className="flex items-start gap-2">
                  <BookOpen size={16} className="text-blue-600 flex-shrink-0 mt-0.5" />
                  <p className="text-xs text-blue-700 leading-relaxed">{q.explanation}</p>
                </div>
              </div>
            )}

            {/* Next button */}
            {showResult && (
              <button
                onClick={handleNext}
                className="w-full py-3.5 rounded-2xl bg-emerald-600 text-white font-semibold text-sm shadow-lg shadow-emerald-500/25 active:scale-[0.98] transition-transform flex items-center justify-center gap-2"
              >
                {currentQ + 1 < questions.length ? 'Next Question' : 'See Results'}
                <ChevronRight size={16} />
              </button>
            )}
          </div>
        </main>
      </div>
    );
  }

  // ---- Result phase ----
  if (phase === 'result') {
    const correctCount = results.filter((r) => r.correct).length;
    const total = results.length;
    const badge =
      score === 100
        ? 'Perfect score!'
        : score >= 80
        ? 'Great work!'
        : score >= 50
        ? 'Good effort!'
        : 'Keep practicing!';

    return (
      <div className="absolute inset-0 z-50 bg-slate-50 flex flex-col animate-fade-in">
        <header className="sticky top-0 z-10 bg-white/80 backdrop-blur-xl border-b border-slate-200/60">
          <div className="px-5 pt-4 pb-3 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-emerald-600 to-teal-500 flex items-center justify-center shadow-md shadow-emerald-500/20">
                <Brain size={18} className="text-white" />
              </div>
              <div>
                <h1 className="text-lg font-bold text-slate-900 leading-tight">Quiz Results</h1>
                <p className="text-xs text-slate-500 leading-tight">{topic?.label}</p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="w-10 h-10 rounded-full flex items-center justify-center text-slate-600 hover:bg-slate-100 active:scale-90 transition-all"
              aria-label="Close"
            >
              <X size={20} strokeWidth={2.2} />
            </button>
          </div>
        </header>

        <main className="flex-1 overflow-y-auto pb-8 no-scrollbar">
          <div className="px-5 py-4 space-y-5">
            {/* Score hero */}
            <div className="text-center py-6">
              <div className="w-20 h-20 rounded-full bg-gradient-to-br from-emerald-400 to-teal-500 flex items-center justify-center mx-auto mb-4 shadow-lg shadow-emerald-500/20">
                <Award size={36} className="text-white" />
              </div>
              <p className="text-lg font-bold text-slate-900">{badge}</p>
              <p className="text-sm text-slate-500 mt-1">{topic?.label} · {difficulty}</p>
              <p className="text-4xl font-bold text-slate-900 mt-3">{score}%</p>
              <p className="text-sm text-slate-500 mt-1">{correctCount} / {total} correct</p>
            </div>

            {/* Score breakdown */}
            <div className="bg-white rounded-2xl p-5 border border-slate-100 shadow-sm space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm text-slate-500">Correct answers</span>
                <span className="flex items-center gap-1 text-sm font-semibold text-emerald-600">
                  <CheckCircle2 size={15} /> {correctCount}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-slate-500">Wrong answers</span>
                <span className="flex items-center gap-1 text-sm font-semibold text-rose-600">
                  <XCircle size={15} /> {total - correctCount}
                </span>
              </div>
              <div className="flex items-center justify-between pt-3 border-t border-slate-50">
                <span className="text-sm text-slate-500">Accuracy</span>
                <span className="text-lg font-bold text-slate-900">{score}%</span>
              </div>
            </div>

            {/* Revision suggestions */}
            {wrongQuestions.length > 0 && (
              <div className="animate-fade-in">
                <div className="flex items-center gap-2 mb-2">
                  <TrendingUp size={15} className="text-amber-600" />
                  <h3 className="text-sm font-bold text-slate-700">What to revise</h3>
                </div>
                <div className="space-y-2.5">
                  {wrongQuestions.map((r, i) => (
                    <div key={i} className="bg-amber-50 rounded-2xl p-3.5 border border-amber-100">
                      <p className="text-sm font-semibold text-slate-800 leading-snug">{r.question.question}</p>
                      <div className="mt-2 flex items-start gap-1.5">
                        <BookOpen size={13} className="text-amber-600 flex-shrink-0 mt-0.5" />
                        <p className="text-xs text-amber-700 leading-relaxed">{r.question.explanation}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {wrongQuestions.length === 0 && (
              <div className="flex items-start gap-2 bg-emerald-50 rounded-2xl p-3.5 border border-emerald-100">
                <CheckCircle2 size={16} className="text-emerald-600 flex-shrink-0 mt-0.5" />
                <p className="text-xs text-emerald-700 leading-relaxed">
                  You got every question right! Try a harder difficulty or a new topic to keep challenging yourself.
                </p>
              </div>
            )}

            {/* Actions */}
            <div className="space-y-2.5">
              <button
                onClick={handleRestart}
                className="w-full py-3.5 rounded-2xl bg-emerald-600 text-white font-semibold text-sm shadow-lg shadow-emerald-500/25 active:scale-[0.98] transition-transform flex items-center justify-center gap-2"
              >
                <RotateCcw size={16} /> Take Another Quiz
              </button>
              <button
                onClick={onClose}
                className="w-full py-3.5 rounded-2xl bg-white border border-slate-200 text-slate-600 font-semibold text-sm active:scale-[0.98] transition-all flex items-center justify-center gap-2"
              >
                <RefreshCw size={16} /> Back to Study
              </button>
            </div>
          </div>
        </main>
      </div>
    );
  }

  return null;
}
