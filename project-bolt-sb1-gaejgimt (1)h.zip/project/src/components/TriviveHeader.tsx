import { Sparkles, RotateCcw } from 'lucide-react';
import type { MainSection } from '@/types';

interface TriviveHeaderProps {
  section: MainSection;
  onReset: () => void;
}

export default function TriviveHeader({ section, onReset }: TriviveHeaderProps) {
  const accent = section === 'lessons' ? 'from-emerald-600 to-teal-500' : 'from-blue-600 to-indigo-600';

  return (
    <header className="sticky top-0 z-30 bg-white/80 backdrop-blur-xl border-b border-slate-200/60">
      <div className="px-5 pt-4 pb-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${accent} flex items-center justify-center shadow-lg`}>
              <Sparkles size={20} className="text-white" />
            </div>
            <div>
              <h1 className="text-lg font-bold text-slate-900 leading-tight tracking-tight">TRIVIVE</h1>
              <p className="text-[11px] text-slate-500 leading-tight">Learn. Earn. Thrive.</p>
            </div>
          </div>
          <button
            onClick={onReset}
            className="w-9 h-9 rounded-full flex items-center justify-center text-slate-400 hover:bg-slate-100 active:scale-90 transition-all"
            aria-label="Reset demo data"
          >
            <RotateCcw size={17} />
          </button>
        </div>
      </div>
    </header>
  );
}
