import { useState, useRef, useCallback } from 'react';
import {
  X,
  Upload,
  Image as ImageIcon,
  Languages,
  Copy,
  Check,
  Trash2,
  Loader2,
  ScanText,
  ArrowRight,
  AlertCircle,
} from 'lucide-react';
import Tesseract from 'tesseract.js';

interface PhotoTranslatorProps {
  onClose: () => void;
}

interface LanguageOption {
  label: string;
  code: string;
}

const LANGUAGES: LanguageOption[] = [
  { label: 'English', code: 'en' },
  { label: 'Hindi', code: 'hi' },
  { label: 'Telugu', code: 'te' },
  { label: 'Kannada', code: 'kn' },
  { label: 'Tamil', code: 'ta' },
  { label: 'Malayalam', code: 'ml' },
  { label: 'Marathi', code: 'mr' },
  { label: 'Bengali', code: 'bn' },
  { label: 'Gujarati', code: 'gu' },
  { label: 'Punjabi', code: 'pa' },
];

const OCR_LANG = 'eng';

export default function PhotoTranslator({ onClose }: PhotoTranslatorProps) {
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [extractedText, setExtractedText] = useState('');
  const [translatedText, setTranslatedText] = useState('');
  const [targetLang, setTargetLang] = useState('hi');
  const [ocrLoading, setOcrLoading] = useState(false);
  const [translateLoading, setTranslateLoading] = useState(false);
  const [error, setError] = useState('');
  const [copied, setCopied] = useState(false);
  const [ocrProgress, setOcrProgress] = useState(0);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const reset = useCallback(() => {
    setImagePreview(null);
    setImageFile(null);
    setExtractedText('');
    setTranslatedText('');
    setError('');
    setCopied(false);
    setOcrProgress(0);
  }, []);

  const handleFileSelect = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!file.type.startsWith('image/')) {
      setError('Please select an image file.');
      return;
    }
    setError('');
    setExtractedText('');
    setTranslatedText('');
    setCopied(false);
    setImageFile(file);
    const reader = new FileReader();
    reader.onload = () => setImagePreview(reader.result as string);
    reader.readAsDataURL(file);
  }, []);

  const runOcr = useCallback(async () => {
    if (!imagePreview) return;
    setOcrLoading(true);
    setOcrProgress(0);
    setError('');
    setExtractedText('');
    setTranslatedText('');
    try {
      const result = await Tesseract.recognize(imagePreview, OCR_LANG, {
        logger: (m: { status: string; progress: number }) => {
          if (m.status === 'recognizing text') {
            setOcrProgress(Math.round(m.progress * 100));
          }
        },
      });
      const text = (result.data.text || '').trim();
      if (!text) {
        setError('No text could be detected in this image. Try a clearer photo.');
      } else {
        setExtractedText(text);
      }
    } catch {
      setError('Failed to read text from the image. Please try again.');
    } finally {
      setOcrLoading(false);
      setOcrProgress(0);
    }
  }, [imagePreview]);

  const handleTranslate = useCallback(async () => {
    if (!extractedText) return;
    setTranslateLoading(true);
    setError('');
    setTranslatedText('');
    try {
      const sourceLang = 'en';
      const langpair = `${sourceLang}|${targetLang}`;
      const url = `https://api.mymemory.translated.net/get?q=${encodeURIComponent(extractedText)}&langpair=${langpair}`;
      const response = await fetch(url);
      if (!response.ok) throw new Error(`Translation failed (${response.status})`);
      const data = await response.json();
      const translated = data?.responseData?.translatedText;
      if (!translated) throw new Error('No translation returned.');
      setTranslatedText(translated);
    } catch {
      setError('Translation failed. Please check your connection and try again.');
    } finally {
      setTranslateLoading(false);
    }
  }, [extractedText, targetLang]);

  const handleCopy = useCallback(async () => {
    if (!translatedText) return;
    try {
      await navigator.clipboard.writeText(translatedText);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      setError('Could not copy to clipboard.');
    }
  }, [translatedText]);

  const targetLangLabel = LANGUAGES.find((l) => l.code === targetLang)?.label ?? '';

  return (
    <div className="absolute inset-0 z-50 bg-slate-50 flex flex-col animate-fade-in">
      {/* Header */}
      <header className="sticky top-0 z-10 bg-white/80 backdrop-blur-xl border-b border-slate-200/60">
        <div className="px-5 pt-4 pb-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-blue-600 to-sky-500 flex items-center justify-center shadow-md shadow-blue-500/20">
              <ScanText size={18} className="text-white" />
            </div>
            <div>
              <h1 className="text-lg font-bold text-slate-900 leading-tight">Translate from Photo</h1>
              <p className="text-xs text-slate-500 leading-tight">Scan text & translate it</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-10 h-10 rounded-full flex items-center justify-center text-slate-600 hover:bg-slate-100 active:scale-90 transition-all"
            aria-label="Close"
          >
            <X size={20} strokeWidth={2.2} />
          </button>
        </div>
      </header>

      <main className="flex-1 overflow-y-auto pb-8 no-scrollbar">
        <div className="px-5 py-4 space-y-5">
          {/* Upload area */}
          {!imagePreview && (
            <div className="animate-scale-in">
              <button
                onClick={() => fileInputRef.current?.click()}
                className="w-full rounded-3xl border-2 border-dashed border-slate-300 bg-white p-8 flex flex-col items-center gap-3 active:scale-[0.98] transition-transform hover:border-blue-400"
              >
                <div className="w-16 h-16 rounded-2xl bg-blue-50 flex items-center justify-center">
                  <Upload size={28} className="text-blue-600" />
                </div>
                <div>
                  <p className="text-sm font-bold text-slate-800">Upload Photo</p>
                  <p className="text-xs text-slate-400 mt-0.5">Tap to select an image from your device</p>
                </div>
              </button>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handleFileSelect}
                className="hidden"
              />
            </div>
          )}

          {/* Image preview + actions */}
          {imagePreview && (
            <div className="animate-scale-in space-y-4">
              <div className="relative rounded-2xl overflow-hidden border border-slate-200 shadow-sm bg-white">
                <img src={imagePreview} alt="Selected" className="w-full max-h-72 object-contain" />
              </div>

              {!extractedText && !ocrLoading && (
                <div className="flex gap-2.5">
                  <button
                    onClick={runOcr}
                    className="flex-1 py-3 rounded-xl bg-blue-600 text-white font-semibold text-sm flex items-center justify-center gap-2 shadow-lg shadow-blue-500/25 active:scale-[0.98] transition-all"
                  >
                    <ScanText size={16} /> Extract Text
                  </button>
                  <button
                    onClick={() => fileInputRef.current?.click()}
                    className="px-4 py-3 rounded-xl bg-white border border-slate-200 text-slate-600 font-semibold text-sm flex items-center justify-center gap-2 active:scale-[0.98] transition-all"
                  >
                    <ImageIcon size={16} />
                  </button>
                </div>
              )}

              {ocrLoading && (
                <div className="bg-white rounded-2xl p-4 border border-slate-100 shadow-sm flex flex-col items-center gap-3">
                  <Loader2 size={24} className="text-blue-600 animate-spin" />
                  <p className="text-sm font-semibold text-slate-700">Reading text from image…</p>
                  <div className="w-full h-2 rounded-full bg-slate-100 overflow-hidden">
                    <div
                      className="h-full rounded-full bg-gradient-to-r from-blue-500 to-sky-500 transition-all"
                      style={{ width: `${ocrProgress}%` }}
                    />
                  </div>
                  <p className="text-xs text-slate-400">{ocrProgress}%</p>
                </div>
              )}
            </div>
          )}

          {/* Hidden file input for "change photo" */}
          {imagePreview && (
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              onChange={handleFileSelect}
              className="hidden"
            />
          )}

          {/* Error */}
          {error && (
            <div className="flex items-start gap-2 bg-rose-50 rounded-2xl p-3.5 border border-rose-100 animate-fade-in">
              <AlertCircle size={16} className="text-rose-600 flex-shrink-0 mt-0.5" />
              <p className="text-xs text-rose-700 leading-relaxed">{error}</p>
            </div>
          )}

          {/* Extracted text */}
          {extractedText && (
            <div className="animate-fade-in">
              <div className="flex items-center gap-2 mb-2">
                <ScanText size={15} className="text-slate-600" />
                <h3 className="text-sm font-bold text-slate-700">Extracted Text</h3>
              </div>
              <div className="bg-white rounded-2xl p-4 border border-slate-100 shadow-sm">
                <p className="text-sm text-slate-800 leading-relaxed whitespace-pre-wrap break-words">
                  {extractedText}
                </p>
              </div>
            </div>
          )}

          {/* Language selector + translate */}
          {extractedText && (
            <div className="animate-fade-in space-y-3">
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <Languages size={15} className="text-slate-600" />
                  <h3 className="text-sm font-bold text-slate-700">Translate To</h3>
                </div>
                <div className="relative">
                  <select
                    value={targetLang}
                    onChange={(e) => setTargetLang(e.target.value)}
                    className="w-full appearance-none bg-white rounded-2xl p-3.5 pr-10 border border-slate-200 shadow-sm text-sm font-semibold text-slate-800 focus:outline-none focus:border-blue-400 focus:ring-2 focus:ring-blue-100"
                  >
                    {LANGUAGES.map((lang) => (
                      <option key={lang.code} value={lang.code}>
                        {lang.label}
                      </option>
                    ))}
                  </select>
                  <div className="absolute right-3.5 top-1/2 -translate-y-1/2 pointer-events-none">
                    <ArrowRight size={16} className="text-slate-400 rotate-90" />
                  </div>
                </div>
              </div>

              <button
                onClick={handleTranslate}
                disabled={translateLoading}
                className="w-full py-3 rounded-xl bg-emerald-600 text-white font-semibold text-sm flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/25 active:scale-[0.98] transition-all disabled:opacity-60"
              >
                {translateLoading ? (
                  <>
                    <Loader2 size={16} className="animate-spin" /> Translating…
                  </>
                ) : (
                  <>
                    <Languages size={16} /> Translate to {targetLangLabel}
                  </>
                )}
              </button>
            </div>
          )}

          {/* Translated text */}
          {translatedText && (
            <div className="animate-fade-in">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <Languages size={15} className="text-emerald-600" />
                  <h3 className="text-sm font-bold text-slate-700">Translation ({targetLangLabel})</h3>
                </div>
                <button
                  onClick={handleCopy}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-50 text-emerald-700 text-xs font-semibold active:scale-95 transition-transform"
                >
                  {copied ? (
                    <>
                      <Check size={14} /> Copied
                    </>
                  ) : (
                    <>
                      <Copy size={14} /> Copy
                    </>
                  )}
                </button>
              </div>
              <div className="bg-gradient-to-br from-emerald-50 to-teal-50 rounded-2xl p-4 border border-emerald-100">
                <p className="text-sm text-slate-800 leading-relaxed whitespace-pre-wrap break-words">
                  {translatedText}
                </p>
              </div>
            </div>
          )}

          {/* Clear / Upload another */}
          {imagePreview && (
            <button
              onClick={reset}
              className="w-full py-3 rounded-xl bg-white border border-slate-200 text-slate-600 font-semibold text-sm flex items-center justify-center gap-2 active:scale-[0.98] transition-all"
            >
              <Trash2 size={16} /> Clear & Upload Another Photo
            </button>
          )}
        </div>
      </main>
    </div>
  );
}
