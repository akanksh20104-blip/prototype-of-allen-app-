import type { StudentProfile, QuizAttempt, WalletTransaction, SavedLesson, Language } from '@/types';

const STORAGE_KEY = 'trivive-student-data';

const todayStr = (): string => new Date().toISOString().split('T')[0];

const DEFAULT_DATA: StudentProfile = {
  preferredLanguage: 'kannada',
  xp: 840,
  streak: 5,
  lastActivityDate: todayStr(),
  savedLessons: [
    {
      id: 'demo-1',
      chapterId: 'photosynthesis',
      chapterName: 'Photosynthesis',
      englishText: 'Photosynthesis is the process by which green plants use sunlight to synthesize foods.',
      translatedText: 'ದ್ಯುತಿಸಂಶ್ಲೇಷಣ್ ಎನ್ನುವುದು ಹಸಿರು ಸಸ್ಯಗಳು ಸೂರ್ಯನ ಬೆಳಕನ್ನು ಬಳಸಿ ಆಹಾರವನ್ನು ಸಂಶ್ಲೇಷಿಸುವ ಪ್ರಕ್ರಿಯೆ.',
      explanation: 'Plants make their own food using sunlight, water, and carbon dioxide.',
      points: ['Chlorophyll captures sunlight', 'Carbon dioxide is absorbed', 'Oxygen is released'],
      language: 'kannada',
      savedAt: '2026-09-25T10:00:00.000Z',
    },
  ],
  completedChapters: ['photosynthesis', 'electricity', 'cells', 'gravity', 'force-motion', 'light'],
  quizHistory: [
    { id: 'q1', chapterId: 'photosynthesis', chapterName: 'Photosynthesis', date: '2026-09-27', totalQuestions: 5, correct: 4, wrong: 1, score: 80, xpEarned: 100, source: 'offline' },
    { id: 'q2', chapterId: 'electricity', chapterName: 'Electricity', date: '2026-09-26', totalQuestions: 5, correct: 5, wrong: 0, score: 100, xpEarned: 150, source: 'offline' },
    { id: 'q3', chapterId: 'cells', chapterName: 'Cells', date: '2026-09-25', totalQuestions: 5, correct: 3, wrong: 2, score: 60, xpEarned: 60, source: 'offline' },
  ],
  walletBalance: 2500,
  walletTransactions: [
    { id: 't1', type: 'debit', category: 'food', title: 'School Canteen', amount: 50, date: '2026-09-27' },
    { id: 't2', type: 'debit', category: 'food', title: 'Lunch', amount: 80, date: '2026-09-26' },
    { id: 't3', type: 'debit', category: 'food', title: 'Juice', amount: 30, date: '2026-09-26' },
    { id: 't4', type: 'debit', category: 'food', title: 'Snack', amount: 40, date: '2026-09-24' },
    { id: 't5', type: 'credit', category: 'scholarship', title: 'Merit Scholarship (₹500)', amount: 500, date: '2026-09-20' },
  ],
  foodBudget: 1500,
  foodSpentThisMonth: 200,
  studyExpenses: [
    { id: 's1', title: 'Science Olympiad', fee: 2000, dueDate: '12 Oct' },
    { id: 's2', title: 'Math Competition', fee: 500, dueDate: '20 Oct' },
    { id: 's3', title: 'School Science Fair', fee: 300, dueDate: '25 Oct' },
  ],
  claimedScholarshipLevels: [],
  scannedChapters: ['photosynthesis', 'electricity'],
};

export function loadStudentData(): StudentProfile {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      saveStudentData(DEFAULT_DATA);
      return DEFAULT_DATA;
    }
    const parsed = JSON.parse(raw) as StudentProfile;
    return { ...DEFAULT_DATA, ...parsed };
  } catch {
    return DEFAULT_DATA;
  }
}

export function saveStudentData(data: StudentProfile): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  } catch {
    // ignore write errors
  }
}

export function resetStudentData(): StudentProfile {
  saveStudentData(DEFAULT_DATA);
  return DEFAULT_DATA;
}

export function updateStreak(data: StudentProfile): StudentProfile {
  const today = todayStr();
  if (data.lastActivityDate === today) return data;
  const yesterday = new Date(Date.now() - 86400000).toISOString().split('T')[0];
  if (data.lastActivityDate === yesterday) {
    return { ...data, streak: data.streak + 1, lastActivityDate: today };
  }
  return { ...data, streak: 1, lastActivityDate: today };
}

export function addQuizAttempt(data: StudentProfile, attempt: QuizAttempt): StudentProfile {
  let updated = { ...data, quizHistory: [...data.quizHistory, attempt] };
  updated = updateStreak(updated);
  updated.xp += attempt.xpEarned;
  if (!updated.completedChapters.includes(attempt.chapterId)) {
    updated.completedChapters = [...updated.completedChapters, attempt.chapterId];
  }
  updated.xp += 20; // quiz completion bonus
  if (attempt.correct === attempt.totalQuestions) {
    updated.xp += 50; // perfect quiz bonus
  }
  return updated;
}

export function addSavedLesson(data: StudentProfile, lesson: SavedLesson): StudentProfile {
  let updated = { ...data, savedLessons: [...data.savedLessons, lesson] };
  updated = updateStreak(updated);
  updated.xp += 20; // lesson completed
  if (!updated.completedChapters.includes(lesson.chapterId)) {
    updated.completedChapters = [...updated.completedChapters, lesson.chapterId];
  }
  if (!updated.scannedChapters.includes(lesson.chapterId)) {
    updated.scannedChapters = [...updated.scannedChapters, lesson.chapterId];
  }
  return updated;
}

export function addWalletTransaction(
  data: StudentProfile,
  tx: Omit<WalletTransaction, 'id'>,
): StudentProfile {
  const transaction: WalletTransaction = { ...tx, id: `tx-${Date.now()}` };
  let newBalance = data.walletBalance;
  if (tx.type === 'credit') newBalance += tx.amount;
  else newBalance -= tx.amount;
  let foodSpent = data.foodSpentThisMonth;
  if (tx.category === 'food' && tx.type === 'debit') foodSpent += tx.amount;
  return {
    ...data,
    walletBalance: newBalance,
    walletTransactions: [...data.walletTransactions, transaction],
    foodSpentThisMonth: foodSpent,
  claimedScholarshipLevels:
    tx.category === 'scholarship' && tx.type === 'credit'
      ? [...data.claimedScholarshipLevels, tx.amount]
      : data.claimedScholarshipLevels,
  };
}

export function claimScholarship(data: StudentProfile, amount: number): StudentProfile {
  return addWalletTransaction(data, {
    type: 'credit',
    category: 'scholarship',
    title: `Merit Scholarship (₹${amount})`,
    amount,
    date: todayStr(),
  });
}

export function setLanguage(data: StudentProfile, lang: Language): StudentProfile {
  return { ...data, preferredLanguage: lang };
}

export function calculateMeritScore(data: StudentProfile): number {
  const totalQuizzes = data.quizHistory.length;
  const avgScore =
    totalQuizzes > 0
      ? data.quizHistory.reduce((sum, q) => sum + q.score, 0) / totalQuizzes
      : 0;
  const quizPerf = (avgScore / 100) * 40;
  const chaptersScore = Math.min((data.completedChapters.length / 8) * 100, 100) * 0.25;
  const streakScore = Math.min((data.streak / 7) * 100, 100) * 0.2;
  const xpScore = Math.min((data.xp / 1000) * 100, 100) * 0.15;
  return Math.round(quizPerf + chaptersScore + streakScore + xpScore);
}

export function getScholarshipEligibility(score: number): { amount: number; label: string } {
  if (score >= 85) return { amount: 1000, label: '₹1,000 merit scholarship eligible' };
  if (score >= 70) return { amount: 500, label: '₹500 learning grant eligible' };
  if (score >= 50) return { amount: 250, label: '₹250 learning grant eligible' };
  return { amount: 0, label: 'Keep learning to unlock support' };
}
