import { useState } from 'react';
import Header from '@/components/Header';
import BottomNav from '@/components/BottomNav';
import HomeScreen from '@/screens/HomeScreen';
import ExploreScreen from '@/screens/ExploreScreen';
import CreateScreen from '@/screens/CreateScreen';
import ActivityScreen from '@/screens/ActivityScreen';
import HealthScreen from '@/screens/HealthScreen';
import ProfileScreen from '@/screens/ProfileScreen';
import type { TabId } from '@/types';
import { X } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<TabId>('home');
  const [profileOpen, setProfileOpen] = useState(false);
  const [language, setLanguage] = useState('English');
  const [course, setCourse] = useState('JEE Advanced — 2 Year');

  const handleOpenProfile = () => setProfileOpen(true);
  const handleSearch = () => setActiveTab('explore');

  const renderScreen = () => {
    switch (activeTab) {
      case 'home':
        return <HomeScreen onExplore={() => setActiveTab('explore')} language={language} course={course} />;
      case 'explore':
        return <ExploreScreen />;
      case 'create':
        return <CreateScreen />;
      case 'activity':
        return <ActivityScreen />;
      case 'profile':
        return <HealthScreen />;
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex justify-center">
      <div className="w-full max-w-md min-h-screen bg-slate-50 relative shadow-2xl flex flex-col">
        <Header activeTab={activeTab} onOpenProfile={handleOpenProfile} onSearch={handleSearch} />
        <main className="flex-1 overflow-y-auto pb-24 no-scrollbar">{renderScreen()}</main>
        <BottomNav activeTab={activeTab} onChange={setActiveTab} />

        {/* Profile overlay — separate from Health tab */}
        {profileOpen && (
          <div className="absolute inset-0 z-50 bg-slate-50 flex flex-col animate-fade-in">
            <header className="sticky top-0 z-10 bg-white/80 backdrop-blur-xl border-b border-slate-200/60">
              <div className="px-5 pt-4 pb-3 flex items-center justify-between">
                <div>
                  <h1 className="text-lg font-bold text-slate-900 leading-tight">My Profile</h1>
                  <p className="text-xs text-slate-500 leading-tight">Your account details</p>
                </div>
                <button
                  onClick={() => setProfileOpen(false)}
                  className="w-10 h-10 rounded-full flex items-center justify-center text-slate-600 hover:bg-slate-100 active:scale-90 transition-all"
                  aria-label="Close profile"
                >
                  <X size={20} strokeWidth={2.2} />
                </button>
              </div>
            </header>
            <main className="flex-1 overflow-y-auto pb-24 no-scrollbar">
              <ProfileScreen language={language} onLanguageChange={setLanguage} course={course} onCourseChange={setCourse} />
            </main>
          </div>
        )}
      </div>
    </div>
  );
}
