import type { ChapterData } from '@/types';

export const CHAPTERS: ChapterData[] = [
  {
    id: 'photosynthesis',
    name: 'Photosynthesis',
    keywords: ['photosynthesis', 'sunlight', 'chlorophyll', 'carbon dioxide', 'plant', 'glucose', 'oxygen', 'leaf', 'stomata'],
    englishText:
      'Photosynthesis is the process by which green plants use sunlight to synthesize foods with the help of chlorophyll. Plants absorb carbon dioxide from the air through stomata and water from the soil through roots. Using energy from sunlight, chlorophyll converts carbon dioxide and water into glucose and oxygen. The oxygen is released into the atmosphere as a byproduct.',
    simpleExplanation:
      'Plants make their own food using sunlight, water, and carbon dioxide. They produce glucose for energy and release oxygen for us to breathe.',
    importantPoints: [
      'Photosynthesis occurs in the leaves of plants',
      'Chlorophyll is the green pigment that captures sunlight',
      'Carbon dioxide is absorbed and oxygen is released',
      'The process produces glucose which plants use for energy',
    ],
    translations: {
      kannada: {
        text: 'ದ್ಯುತಿಸಂಶ್ಲೇಷಣ್ ಎನ್ನುವುದು ಹಸಿರು ಸಸ್ಯಗಳು ಸೂರ್ಯನ ಬೆಳಕನ್ನು ಬಳಸಿ ಕ್ಲೋರೋಫಿಲ್ ಸಹಾಯದಿಂದ ಆಹಾರವನ್ನು ಸಂಶ್ಲೇಷಿಸುವ ಪ್ರಕ್ರಿಯೆ. ಸಸ್ಯಗಳು ಗಾಳಿಯಿಂದ ಕಾರ್ಬನ್ ಡೈಆಕ್ಸೈಡ್ ಅನ್ನು ಮತ್ತು ಮಣ್ಣಿನಿಂದ ನೀರನ್ನು ಹೀರಿಕೊಳ್ಳುತ್ತವೆ. ಸೂರ್ಯನ ಬೆಳಕಿನ ಶಕ್ತಿಯಿಂದ ಕ್ಲೋರೋಫಿಲ್ ಕಾರ್ಬನ್ ಡೈಆಕ್ಸೈಡ್ ಮತ್ತು ನೀರನ್ನು ಗ್ಲೂಕೋಸ್ ಮತ್ತು ಆಮ್ಲಜನವಾಗಿ ಪರಿವರ್ತಿಸುತ್ತದೆ.',
        explanation: 'ಸಸ್ಯಗಳು ಸೂರ್ಯನ ಬೆಳಕು, ನೀರು ಮತ್ತು ಕಾರ್ಬನ್ ಡೈಆಕ್ಸೈಡ್ ಬಳಸಿ ತಮ್ಮ ಆಹಾರವನ್ನು ತಾವೇ ತಯಾರಿಸುತ್ತವೆ. ಅವು ಗ್ಲೂಕೋಸ್ ಅನ್ನು ಶಕ್ತಿಗಾಗಿ ಉತ್ಪಾದಿಸುತ್ತವೆ ಮತ್ತು ನಮಗೆ ಉಸಿರಾಡಲು ಆಮ್ಲಜನವನ್ನು ಬಿಡುತ್ತವೆ.',
        points: [
          'ದ್ಯುತಿಸಂಶ್ಲೇಷಣ್ ಸಸ್ಯದ ಎಲೆಗಳಲ್ಲಿ ನಡೆಯುತ್ತದೆ',
          'ಕ್ಲೋರೋಫಿಲ್ ಎನ್ನುವುದು ಸೂರ್ಯನ ಬೆಳಕನ್ನು ಹೀರಿಕೊಳ್ಳುವ ಹಸಿರು ವರ್ಣದ್ರವ್ಯ',
          'ಕಾರ್ಬನ್ ಡೈಆಕ್ಸೈಡ್ ಹೀರಲ್ಪಡುತ್ತದೆ ಮತ್ತು ಆಮ್ಲಜನ ಬಿಡಲ್ಪಡುತ್ತದೆ',
          'ಈ ಪ್ರಕ್ರಿಯೆಯು ಗ್ಲೂಕೋಸ್ ಅನ್ನು ಉತ್ಪಾದಿಸುತ್ತದೆ',
        ],
      },
      hindi: {
        text: 'प्रकाश संश्लेषण वह प्रक्रिया है जिसमें हरे पौधे सूर्य के प्रकाश का उपयोग करके क्लोरोफिल की सहायता से भोजन बनाते हैं। पौधे वायु से कार्बन डाइऑक्साइड ग्रहण करते हैं और जड़ों से पानी लेते हैं। सूर्य के प्रकाश से क्लोरोफिल कार्बन डाइऑक्साइड और पानी को ग्लूकोज और ऑक्सीजन में बदलता है।',
        explanation: 'पौधे सूर्य की रोशनी, पानी और कार्बन डाइऑक्साइड का उपयोग करके अपना भोजन स्वयं बनाते हैं। वे ऊर्जा के लिए ग्लूकोज बनाते हैं और हमारे लिए ऑक्सीजन छोड़ते हैं।',
        points: [
          'प्रकाश संश्लेषण पौधे की पत्तियों में होता है',
          'क्लोरोफिल सूर्य के प्रकाश को ग्रहण करने वाला हरा वर्णक है',
          'कार्बन डाइऑक्साइड ग्रहण किया जाता है और ऑक्सीजन छोड़ा जाता है',
          'यह प्रक्रिया ग्लूकोज का उत्पादन करती है',
        ],
      },
    },
    questions: [
      { question: 'Which gas is absorbed during photosynthesis?', options: ['Oxygen', 'Carbon dioxide', 'Nitrogen', 'Hydrogen'], correctIndex: 1 },
      { question: 'What is the green pigment in plants called?', options: ['Carotene', 'Chlorophyll', 'Xanthophyll', 'Melanin'], correctIndex: 1 },
      { question: 'What do plants release as a byproduct of photosynthesis?', options: ['Carbon dioxide', 'Nitrogen', 'Oxygen', 'Methane'], correctIndex: 2 },
      { question: 'Where does photosynthesis primarily occur?', options: ['Roots', 'Stem', 'Leaves', 'Flowers'], correctIndex: 2 },
      { question: 'What sugar is produced during photosynthesis?', options: ['Sucrose', 'Fructose', 'Glucose', 'Lactose'], correctIndex: 2 },
    ],
  },
  {
    id: 'force-motion',
    name: 'Force and Motion',
    keywords: ['force', 'motion', 'newton', 'velocity', 'acceleration', 'speed', 'friction', 'momentum', 'inertia'],
    englishText:
      'Force is a push or pull that can change the state of motion of an object. Newton\'s first law states that an object at rest stays at rest and an object in motion stays in motion unless acted upon by an external force. Acceleration is the rate of change of velocity. Force equals mass times acceleration (F = ma). Friction is a force that opposes motion between two surfaces in contact.',
    simpleExplanation:
      'Force is a push or pull. Things stay still or keep moving unless a force acts on them. Heavier objects need more force to accelerate.',
    importantPoints: [
      'Force = mass × acceleration (F = ma)',
      'Newton\'s first law is the law of inertia',
      'Friction opposes motion between surfaces',
      'Acceleration is the rate of change of velocity',
    ],
    translations: {
      kannada: {
        text: 'ಬಲವು ಎನ್ನುವುದು ಒಂದು ವಸ್ತುವಿನ ಚಲನೆಯ ಸ್ಥಿತಿಯನ್ನು ಬದಲಾಯಿಸಬಲ್ಲ ತಳ್ಳುವ ಅಥವಾ ಎಳೆಯುವ ಶಕ್ತಿ. ನ್ಯೂಟನ್ ಮೊದಲ ನಿಯಮದ ಪ್ರಕಾರ, ಬಾಹ್ಯ ಬಲವು ಪ್ರಯೋಗಿಸದ ಹೊರತು ವಿಶ್ರಾಂತ ಸ್ಥಿತಿಯಲ್ಲಿರುವ ವಸ್ತು ವಿಶ್ರಾಂತವಾಗಿಯೇ ಇರುತ್ತದೆ. ವೇಗೋತ್ಕರ್ಷವು ವೇಗದ ಬದಲಾವಣೆಯ ದರ. ಬಲ = ದ್ರವ್ಯರಾಶಿ × ವೇಗೋತ್ಕರ್ಷ.',
        explanation: 'ಬಲವು ಒಂದು ತಳ್ಳು ಅಥವಾ ಎಳೆತ. ಬಾಹ್ಯ ಬಲವು ಪ್ರಯೋಗಿಸದ ಹೊರತು ವಸ್ತುಗಳು ತಮ್ಮ ಸ್ಥಿತಿಯನ್ನು ಬದಲಾಯಿಸುವುದಿಲ್ಲ. ಭಾರೀ ವಸ್ತುಗಳಿಗೆ ವೇಗೋತ್ಕರ್ಷಕ್ಕೆ ಹೆಚ್ಚು ಬಲ ಬೇಕು.',
        points: [
          'ಬಲ = ದ್ರವ್ಯರಾಶಿ × ವೇಗೋತ್ಕರ್ಷ (F = ma)',
          'ನ್ಯೂಟನ್ ಮೊದಲ ನಿಯಮವು ಜಡತ್ವದ ನಿಯಮ',
          'ಘರ್ಷಣೆಯು ಮೇಲ್ಮೈಗಳ ನಡುವಿನ ಚಲನೆಯನ್ನು ವಿರೋಧಿಸುತ್ತದೆ',
          'ವೇಗೋತ್ಕರ್ಷವು ವೇಗದ ಬದಲಾವಣೆಯ ದರ',
        ],
      },
      hindi: {
        text: 'बल वह धक्का या खिंचाव है जो किसी वस्तु की गति की स्थिति को बदल सकता है। न्यूटन के पहले नियम के अनुसार, बाहरी बल लगने तक स्थिर वस्तु स्थिर रहती है और गतिमान वस्तु गतिमान रहती है। त्वरण वेग में परिवर्तन की दर है। बल = द्रव्यमान × त्वरण।',
        explanation: 'बल एक धक्का या खिंच है। बाहरी बल लगे बिना वस्तुएं अपनी स्थिति नहीं बदलतीं। भारी वस्तुओं को त्वरित करने के लिए अधिक बल चाहिए।',
        points: [
          'बल = द्रव्यमान × त्वरण (F = ma)',
          'न्यूटन का पहला नियम जड़त्व का नियम है',
          'घर्षण दो सतहों के बीच गति का विरोध करता है',
          'त्वरण वेग में परिवर्तन की दर है',
        ],
      },
    },
    questions: [
      { question: 'What is the SI unit of force?', options: ['Joule', 'Newton', 'Watt', 'Pascal'], correctIndex: 1 },
      { question: 'Force equals mass times what?', options: ['Velocity', 'Distance', 'Acceleration', 'Time'], correctIndex: 2 },
      { question: "Newton's first law is also known as the law of?", options: ['Gravity', 'Inertia', 'Friction', 'Momentum'], correctIndex: 1 },
      { question: 'Which force opposes motion between surfaces?', options: ['Magnetic', 'Friction', 'Tension', 'Buoyancy'], correctIndex: 1 },
      { question: 'Acceleration is the rate of change of?', options: ['Mass', 'Force', 'Velocity', 'Energy'], correctIndex: 2 },
    ],
  },
  {
    id: 'gravity',
    name: 'Gravity',
    keywords: ['gravity', 'force', 'earth', 'mass', 'attraction', 'weight', 'newton', 'fall', 'orbit', 'planet'],
    englishText:
      'Gravity is the force by which a planet or other body draws objects toward its center. The force of gravity keeps all the planets in orbit around the sun. Newton\'s law of universal gravitation states that every particle attracts every other particle with a force proportional to their masses and inversely proportional to the square of the distance between them. Weight is the force of gravity acting on an object.',
    simpleExplanation:
      'Gravity is the force that pulls objects toward each other. It keeps us on the ground and makes things fall when dropped.',
    importantPoints: [
      'Gravity pulls objects toward the center of the Earth',
      'Weight = mass × gravitational acceleration (W = mg)',
      'Gravity keeps planets in orbit around the sun',
      'Greater mass means greater gravitational force',
    ],
    translations: {
      kannada: {
        text: 'ಗುರುತ್ವಾಕರ್ಷಣವು ಒಂದು ಗ್ರಹ ಅಥವಾ ಇತರ ವಸ್ತುವನ್ನು ತನ್ನ ಕೇಂದ್ರದೆಡೆಗೆ ಎಳೆಯುವ ಬಲ. ಗುರುತ್ವಾಕರ್ಷಣ ಬಲವು ಎಲ್ಲಾ ಗ್ರಹಗಳನ್ನು ಸೂರ್ಯನ ಸುತ್ತ ಕಕ್ಷೆಯಲ್ಲಿ ಇರಿಸುತ್ತದೆ. ನ್ಯೂಟನ್ ಸಾರ್ವತ್ರಿಕ ಗುರುತ್ವಾಕರ್ಷಣ ನಿಯಮದ ಪ್ರಕಾರ ಪ್ರತಿ ಕಣವು ಇನ್ನೊಂದು ಕಣವನ್ನು ಆಕರ್ಷಿಸುತ್ತದೆ.',
        explanation: 'ಗುರುತ್ವಾಕರ್ಷಣವು ವಸ್ತುಗಳನ್ನು ಪರಸ್ಪರ ಕಡೆಗೆ ಎಳೆಯುವ ಬಲ. ಅದು ನಮ್ಮನ್ನು ನೆಲದ ಮೇಲೆ ಇರಿಸುತ್ತದೆ ಮತ್ತು ಬಿದ್ದ ವಸ್ತುಗಳನ್ನು ಕೆಳಗೆ ಬೀಳಿಸುತ್ತದೆ.',
        points: [
          'ಗುರುತ್ವಾಕರ್ಷಣವು ವಸ್ತುಗಳನ್ನು ಭೂಮಿಯ ಕೇಂದ್ರದೆಡೆಗೆ ಎಳೆಯುತ್ತದೆ',
          'ತೂಕ = ದ್ರವ್ಯರಾಶಿ × ಗುರುತ್ವಾಕರ್ಷಣ ವೇಗೋತ್ಕರ್ಷ (W = mg)',
          'ಗುರುತ್ವಾಕರ್ಷಣವು ಗ್ರಹಗಳನ್ನು ಸೂರ್ಯನ ಸುತ್ತ ಕಕ್ಷೆಯಲ್ಲಿ ಇರಿಸುತ್ತದೆ',
          'ಹೆಚ್ಚಿನ ದ್ರವ್ಯರಾಶಿ ಎಂದರೆ ಹೆಚ್ಚಿನ ಗುರುತ್ವಾಕರ್ಷಣ ಬಲ',
        ],
      },
      hindi: {
        text: 'गुरुत्वाकर्षण वह बल है जिससे कोई ग्रह या वस्तु अन्य वस्तुओं को अपने केंद्र की ओर खींचता है। गुरुत्वाकर्षण बल सभी ग्रहों को सूर्य की कक्षा में बनाए रखता है। न्यूटन के सार्वभौम गुरुत्वाकर्षण नियम के अनुसार प्रत्येक कण दूसरे कण को आकर्षित करता है।',
        explanation: 'गुरुत्वाकर्षण वह बल है जो वस्तुओं को एक-दूसरे की ओर खींचता है। यह हमें जमीन पर रखता है और गिरने वाली चीजों को नीचे गिराता है।',
        points: [
          'गुरुत्वाकर्षण वस्तुओं को पृथ्वी के केंद्र की ओर खींचता है',
          'भार = द्रव्यमान × गुरुत्वीय त्वरण (W = mg)',
          'गुरुत्वाकर्षण ग्रहों को सूर्य की कक्षा में रखता है',
          'अधिक द्रव्यमान का अर्थ अधिक गुरुत्वाकर्षण बल है',
        ],
      },
    },
    questions: [
      { question: 'What is the acceleration due to gravity on Earth?', options: ['8.9 m/s²', '9.8 m/s²', '10.8 m/s²', '11.8 m/s²'], correctIndex: 1 },
      { question: 'Weight is equal to mass times?', options: ['Velocity', 'Gravity', 'Time', 'Distance'], correctIndex: 1 },
      { question: 'Who formulated the law of universal gravitation?', options: ['Einstein', 'Galileo', 'Newton', 'Kepler'], correctIndex: 2 },
      { question: 'Gravity is a force of?', options: ['Repulsion', 'Attraction', 'Friction', 'Tension'], correctIndex: 1 },
      { question: 'What keeps planets in orbit around the sun?', options: ['Magnetism', 'Gravity', 'Friction', 'Air resistance'], correctIndex: 1 },
    ],
  },
  {
    id: 'electricity',
    name: 'Electricity',
    keywords: ['electricity', 'current', 'voltage', 'circuit', 'resistance', 'electric', 'charge', 'ohm', 'conductor', 'insulator'],
    englishText:
      'Electricity is the flow of electric charge through a conductor. Current is the rate of flow of charge, measured in amperes. Voltage is the potential difference that drives current, measured in volts. Resistance opposes the flow of current, measured in ohms. Ohm\'s law states that voltage equals current times resistance (V = IR). A complete circuit is needed for current to flow.',
    simpleExplanation:
      'Electricity is the flow of electric charge. Voltage pushes it, resistance slows it down, and current is how much flows.',
    importantPoints: [
      'Ohm\'s law: V = IR (Voltage = Current × Resistance)',
      'Current is measured in amperes (A)',
      'Voltage is measured in volts (V)',
      'A complete circuit is required for current flow',
    ],
    translations: {
      kannada: {
        text: 'ವಿದ್ಯುತ್ ಎನ್ನುವುದು ವಾಹಕದ ಮೂಲಕ ವಿದ್ಯುತ್ ಆವೇಶದ ಹರಿವು. ಪ್ರವಾಹವು ಆವೇಶದ ಹರಿವಿನ ದರ, ಆಂಪಿಯರ್‌ಗಳಲ್ಲಿ ಅಳೆಯಲಾಗುತ್ತದೆ. ವೋಲ್ಟೇಜ್ ಪ್ರವಾಹವನ್ನು ಚಾಲಿಸುವ ವಿಭವಾಂತರ. ಪ್ರತಿರೋಧವು ಪ್ರವಾಹದ ಹರಿವನ್ನು ವಿರೋಧಿಸುತ್ತದೆ. ಓಮ್ ನಿಯಮ: V = IR.',
        explanation: 'ವಿದ್ಯುತ್ ಎನ್ನುವುದು ವಿದ್ಯುತ್ ಆವೇಶದ ಹರಿವು. ವೋಲ್ಟೇಜ್ ಅದನ್ನು ತಳ್ಳುತ್ತದೆ, ಪ್ರತಿರೋಧವು ನಿಧಾನಗೊಳಿಸುತ್ತದೆ, ಪ್ರವಾಹವು ಎಷ್ಟು ಹರಿಯುತ್ತದೆ ಎಂಬುದಾಗಿದೆ.',
        points: [
          'ಓಮ್ ನಿಯಮ: V = IR (ವೋಲ್ಟೇಜ್ = ಪ್ರವಾಹ × ಪ್ರತಿರೋಧ)',
          'ಪ್ರವಾಹವನ್ನು ಆಂಪಿಯರ್‌ಗಳಲ್ಲಿ ಅಳೆಯಲಾಗುತ್ತದೆ',
          'ವೋಲ್ಟೇಜ್ ಅನ್ನು ವೋಲ್ಟ್‌ಗಳಲ್ಲಿ ಅಳೆಯಲಾಗುತ್ತದೆ',
          'ಪ್ರವಾಹ ಹರಿಯಲು ಸಂಪೂರ್ಣ ಸರ್ಕ್ಯೂಟ್ ಅಗತ್ಯ',
        ],
      },
      hindi: {
        text: 'विद्युत चालक के माध्यम से विद्युत आवेश का प्रवाह है। धारा आवेश के प्रवाह की दर है, जिसे एम्पीयर में मापा जाता है। वोल्टेज वह विभवांतर है जो धारा को चलाता है। प्रतिरोध धारा के प्रवाह का विरोध करता है। ओम का नियम: V = IR.',
        explanation: 'विद्युत आवेश का प्रवाह है। वोल्टेज इसे धकेलता है, प्रतिरोध इसे धीमा करता है, और धारा कितना प्रवाहित होता है वही धारा है।',
        points: [
          'ओम का नियम: V = IR (वोल्टेज = धारा × प्रतिरोध)',
          'धारा को एम्पीयर (A) में मापा जाता है',
          'वोल्टेज को वोल्ट (V) में मापा जाता है',
          'धारा प्रवाह के लिए पूर्ण परिपथ आवश्यक है',
        ],
      },
    },
    questions: [
      { question: "What is Ohm's law?", options: ['V = IR', 'V = I/R', 'V = R/I', 'V = I²R'], correctIndex: 0 },
      { question: 'What is the unit of electric current?', options: ['Volt', 'Watt', 'Ampere', 'Ohm'], correctIndex: 2 },
      { question: 'What is the unit of resistance?', options: ['Volt', 'Ampere', 'Ohm', 'Watt'], correctIndex: 2 },
      { question: 'What is needed for current to flow?', options: ['A battery only', 'A complete circuit', 'A switch only', 'A wire only'], correctIndex: 1 },
      { question: 'What does voltage measure?', options: ['Current flow', 'Potential difference', 'Resistance', 'Power'], correctIndex: 1 },
    ],
  },
  {
    id: 'digestive-system',
    name: 'Human Digestive System',
    keywords: ['digestive', 'digestion', 'stomach', 'intestine', 'enzyme', 'absorb', 'nutrition', 'mouth', 'liver', 'pancreas'],
    englishText:
      'The human digestive system breaks down food into nutrients that the body can absorb. Digestion begins in the mouth where food is chewed and mixed with saliva. Food then travels through the esophagus to the stomach, where acids and enzymes break it down further. The small intestine absorbs nutrients, while the large intestine absorbs water. The liver produces bile to help digest fats.',
    simpleExplanation:
      'Your digestive system breaks food into nutrients. It starts in your mouth, goes through your stomach, and nutrients are absorbed in your intestines.',
    importantPoints: [
      'Digestion begins in the mouth with chewing and saliva',
      'The stomach uses acid and enzymes to break down food',
      'The small intestine absorbs most nutrients',
      'The large intestine absorbs water',
    ],
    translations: {
      kannada: {
        text: 'ಮಾನವ ಜೀರ್ಣಾಂಗ ವ್ಯವಸ್ಥೆಯು ಆಹಾರವನ್ನು ದೇಹವು ಹೀರಿಕೊಳ್ಳಬಲ್ಲ ಪೋಷಕಾಂಶಗಳಾಗಿ ಒಡೆಯುತ್ತದೆ. ಜೀರ್ಣಕ್ರಿಯೆಯು ಬಾಯಿಯಲ್ಲಿ ಪ್ರಾರಂಭವಾಗುತ್ತದೆ. ಆಹಾರವು ಅನ್ನನಾಳದ ಮೂಲಕ ಜಠರಕ್ಕೆ ಹೋಗುತ್ತದೆ. ಸಣ್ಣ ಕರುಳು ಪೋಷಕಾಂಶಗಳನ್ನು ಹೀರಿಕೊಳ್ಳುತ್ತದೆ, ದೊಡ್ಡ ಕರುಳು ನೀರನ್ನು ಹೀರಿಕೊಳ್ಳುತ್ತದೆ.',
        explanation: 'ನಿಮ್ಮ ಜೀರ್ಣಾಂಗ ವ್ಯವಸ್ಥೆಯು ಆಹಾರವನ್ನು ಪೋಷಕಾಂಶಗಳಾಗಿ ಒಡೆಯುತ್ತದೆ. ಇದು ಬಾಯಿಯಲ್ಲಿ ಪ್ರಾರಂಭವಾಗಿ ಜಠರದ ಮೂಲಕ ಹಾದು ಕರುಳುಗಳಲ್ಲಿ ಹೀರಿಕೊಳ್ಳಲ್ಪಡುತ್ತದೆ.',
        points: [
          'ಜೀರ್ಣಕ್ರಿಯೆಯು ಬಾಯಿಯಲ್ಲಿ ಅಗಿಯುವುದರಿಂದ ಪ್ರಾರಂಭವಾಗುತ್ತದೆ',
          'ಜಠರವು ಆಮ್ಲ ಮತ್ತು ಕಿಣ್ವಗಳನ್ನು ಬಳಸಿ ಆಹಾರವನ್ನು ಒಡೆಯುತ್ತದೆ',
          'ಸಣ್ಣ ಕರುಳು ಹೆಚ್ಚಿನ ಪೋಷಕಾಂಶಗಳನ್ನು ಹೀರಿಕೊಳ್ಳುತ್ತದೆ',
          'ದೊಡ್ಡ ಕರುಳು ನೀರನ್ನು ಹೀರಿಕೊಳ್ಳುತ್ತದೆ',
        ],
      },
      hindi: {
        text: 'मानव पाचन तंत्र भोजन को शरीर द्वारा अवशोषित किए जा सकने वाले पोषक तत्वों में तोड़ता है। पाचन मुँह से शुरू होता है जहाँ भोजन चबाया जाता है। भोजन आमाशय से गुजरता है जहाँ एसिड और एंजाइम इसे तोड़ते हैं। छोटी आंत पोषक तत्वों को अवशोषित करती है।',
        explanation: 'आपका पाचन तंत्र भोजन को पोषक तत्वों में तोड़ता है। यह मुँह से शुरू होता है, पेट से गुजरता है, और आंतों में अवशोषित होता है।',
        points: [
          'पाचन मुँह में चबाने से शुरू होता है',
          'आमाशय एसिड और एंजाइम से भोजन तोड़ता है',
          'छोटी आंत अधिकांश पोषक तत्वों को अवशोषित करती है',
          'बड़ी आंत पानी अवशोषित करती है',
        ],
      },
    },
    questions: [
      { question: 'Where does digestion begin?', options: ['Stomach', 'Mouth', 'Small intestine', 'Liver'], correctIndex: 1 },
      { question: 'Which organ absorbs most nutrients?', options: ['Stomach', 'Large intestine', 'Small intestine', 'Esophagus'], correctIndex: 2 },
      { question: 'What does the stomach use to break down food?', options: ['Bile only', 'Acid and enzymes', 'Water only', 'Air'], correctIndex: 1 },
      { question: 'What does the large intestine absorb?', options: ['Nutrients', 'Water', 'Fat', 'Protein'], correctIndex: 1 },
      { question: 'Which organ produces bile?', options: ['Pancreas', 'Stomach', 'Liver', 'Gallbladder'], correctIndex: 2 },
    ],
  },
  {
    id: 'cells',
    name: 'Cells',
    keywords: ['cell', 'nucleus', 'membrane', 'cytoplasm', 'mitochondria', 'tissue', 'organ', 'organism', 'ribosome', 'chromosome'],
    englishText:
      'The cell is the basic structural and functional unit of life. Cells have a cell membrane that controls what enters and exits. The nucleus contains genetic material (DNA). The cytoplasm is the jelly-like substance where cell activities occur. Mitochondria are the powerhouse of the cell, producing energy. Ribosomes make proteins. Cells form tissues, tissues form organs, and organs form organ systems.',
    simpleExplanation:
      'Cells are the building blocks of life. They have a membrane, a nucleus with DNA, and parts like mitochondria that make energy.',
    importantPoints: [
      'The cell is the basic unit of life',
      'The nucleus contains DNA',
      'Mitochondria produce energy (powerhouse of the cell)',
      'Cells form tissues, tissues form organs',
    ],
    translations: {
      kannada: {
        text: 'ಜೀಕೋಶವು ಜೀವನ ಮೂಲಭೂತ ರಚನಾತ್ಮಕ ಮತ್ತು ಕ್ರಿಯಾತ್ಮಕ ಘಟಕ. ಜೀಕೋಶದ ಪೊರೆಯು ಒಳಬರುವ ಮತ್ತು ಹೊರಹೋಗುವ ವಿಷಯಗಳನ್ನು ನಿಯಂತ್ರಿಸುತ್ತದೆ. ಕೇಂದ್ರಕವು ಆನುವಂಶಿಕ ವಸ್ತುವನ್ನು ಹೊಂದಿದೆ. ಮೈಟೊಕಾಂಡ್ರಿಯಾ ಜೀಕೋಶದ ಶಕ್ತಿ ಕೇಂದ್ರ.',
        explanation: 'ಜೀಕೋಶಗಳು ಜೀವನ ನಿರ್ಮಾಣ ಘಟಕಗಳು. ಅವು ಪೊರೆ, DNA ಹೊಂದಿರುವ ಕೇಂದ್ರಕ ಮತ್ತು ಶಕ್ತಿ ಉತ್ಪಾದಿಸುವ ಮೈಟೊಕಾಂಡ್ರಿಯಾವನ್ನು ಹೊಂದಿವೆ.',
        points: [
          'ಜೀಕೋಶವು ಜೀವನ ಮೂಲಭೂತ ಘಟಕ',
          'ಕೇಂದ್ರಕವು DNA ಅನ್ನು ಹೊಂದಿದೆ',
          'ಮೈಟೊಕಾಂಡ್ರಿಯಾ ಶಕ್ತಿ ಉತ್ಪಾದಿಸುತ್ತದೆ (ಜೀಕೋಶದ ಶಕ್ತಿ ಕೇಂದ್ರ)',
          'ಜೀಕೋಶಗಳು ಅಂಗಾಂಶಗಳನ್ನು, ಅಂಗಾಂಶಗಳು ಅಂಗಗಳನ್ನು ನಿರ್ಮಿಸುತ್ತವೆ',
        ],
      },
      hindi: {
        text: 'कोशिका जीवन की मूलभूत संरचनात्मक और क्रियात्मक इकाई है। कोशिका झिल्ली नियंत्रित करती है कि क्या प्रवेश करे। केंद्रक में आनुवंशिक पदार्थ (DNA) होता है। माइटोकॉन्ड्रिया कोशिका का ऊर्जा केंद्र है। कोशिकाएं ऊतक बनाती हैं।',
        explanation: 'कोशिकाएं जीवन के निर्माण खंड हैं। इनमें झिल्ली, DNA वाला केंद्रक और ऊर्जा बनाने वाले माइटोकॉन्ड्रिया होते हैं।',
        points: [
          'कोशिका जीवन की मूलभूत इकाई है',
          'केंद्रक में DNA होता है',
          'माइटोकॉन्ड्रिया ऊर्जा उत्पन्न करते हैं (कोशिका का ऊर्जा केंद्र)',
          'कोशिकाएं ऊतक बनाती हैं, ऊतक अंग बनाते हैं',
        ],
      },
    },
    questions: [
      { question: 'What is the basic unit of life?', options: ['Atom', 'Cell', 'Tissue', 'Organ'], correctIndex: 1 },
      { question: 'Which part of the cell contains DNA?', options: ['Cytoplasm', 'Membrane', 'Nucleus', 'Ribosome'], correctIndex: 2 },
      { question: 'What is the powerhouse of the cell?', options: ['Nucleus', 'Ribosome', 'Mitochondria', 'Vacuole'], correctIndex: 2 },
      { question: 'What controls what enters and exits the cell?', options: ['Nucleus', 'Cell membrane', 'Cytoplasm', 'Wall'], correctIndex: 1 },
      { question: 'Cells form what?', options: ['Atoms', 'Tissues', 'Molecules', 'Elements'], correctIndex: 1 },
    ],
  },
  {
    id: 'light',
    name: 'Light',
    keywords: ['light', 'reflection', 'refraction', 'lens', 'mirror', 'prism', 'spectrum', 'wavelength', 'optics', 'transparent'],
    englishText:
      'Light is a form of energy that travels in waves. Reflection occurs when light bounces off a surface. Refraction is the bending of light as it passes from one medium to another. A concave lens diverges light rays, while a convex lens converges them. White light is made of seven colors (VIBGYOR). The speed of light in vacuum is approximately 3 × 10⁸ m/s.',
    simpleExplanation:
      'Light is energy that travels in waves. It bounces off surfaces (reflection) and bends when passing through different materials (refraction).',
    importantPoints: [
      'Light travels at 3 × 10⁸ m/s in vacuum',
      'Reflection is light bouncing off a surface',
      'Refraction is light bending between media',
      'White light contains seven colors (VIBGYOR)',
    ],
    translations: {
      kannada: {
        text: 'ಬೆಳಕು ಎನ್ನುವುದು ತರಂಗಗಳಲ್ಲಿ ಪ್ರಯಾಣಿಸುವ ಶಕ್ತಿ. ಪ್ರತಿಫಲನವು ಬೆಳಕು ಮೇಲ್ಮೈಯಿಂದ ತಗ್ಗಿದಾಗ ಸಂಭವಿಸುತ್ತದೆ. ವಕ್ರೀಭವನವು ಬೆಳಕು ಒಂದು ಮಾಧ್ಯಮದಿಂದ ಇನ್ನೊಂದಕ್ಕೆ ಹಾದುಹೋದಾಗ ಬಾಗುವುದು. ಬಿಳಿ ಬೆಳಕು ಏಳು ಬಣ್ಣಗಳಿಂದ ಮಾಡಲ್ಪಟ್ಟಿದೆ.',
        explanation: 'ಬೆಳಕು ತರಂಗಗಳಲ್ಲಿ ಪ್ರಯಾಣಿಸುವ ಶಕ್ತಿ. ಇದು ಮೇಲ್ಮೈಗಳಿಂದ ತಗ್ಗುತ್ತದೆ (ಪ್ರತಿಫಲನ) ಮತ್ತು ವಿವಿಧ ಮಾಧ್ಯಮಗಳ ಮೂಲಕ ಹಾದುಹೋದಾಗ ಬಾಗುತ್ತದೆ (ವಕ್ರೀಭವನ).',
        points: [
          'ಬೆಳಕು ನಿರ್ವಾತಾಕಾಶದಲ್ಲಿ 3 × 10⁸ m/s ವೇಗದಲ್ಲಿ ಪ್ರಯಾಣಿಸುತ್ತದೆ',
          'ಪ್ರತಿಫಲನವು ಬೆಳಕು ಮೇಲ್ಮೈಯಿಂದ ತಗ್ಗುವುದು',
          'ವಕ್ರೀಭವನವು ಮಾಧ್ಯಮಗಳ ನಡುವೆ ಬೆಳಕು ಬಾಗುವುದು',
          'ಬಿಳಿ ಬೆಳಕು ಏಳು ಬಣ್ಣಗಳನ್ನು ಹೊಂದಿದೆ (VIBGYOR)',
        ],
      },
      hindi: {
        text: 'प्रकाश ऊर्जा का रूप है जो तरंगों में यात्रा करता है। परावर्तन तब होता है जब प्रकाक सतह से टकराता है। अपवर्तन प्रकाश का एक माध्यम से दूसरे में झुकना है। सफेद प्रकाश सात रंगों से बना है।',
        explanation: 'प्रकाश तरंगों में यात्रा करने वाली ऊर्जा है। यह सतहों से टकराता है (परावर्तन) और विभिन्न माध्यमों से गुजरते हुए झुकता है (अपवर्तन)।',
        points: [
          'प्रकाश निर्वात में 3 × 10⁸ m/s गति से यात्रा करता है',
          'परावर्तन प्रकाश का सतह से टकराना है',
          'अपवर्तन माध्यमों के बीच प्रकाश का झुकना है',
          'सफेद प्रकाश में सात रंग होते हैं (VIBGYOR)',
        ],
      },
    },
    questions: [
      { question: 'What is the speed of light in vacuum?', options: ['3 × 10⁶ m/s', '3 × 10⁸ m/s', '3 × 10¹⁰ m/s', '3 × 10⁴ m/s'], correctIndex: 1 },
      { question: 'What is reflection?', options: ['Light bending', 'Light bouncing off a surface', 'Light absorbing', 'Light splitting'], correctIndex: 1 },
      { question: 'What is refraction?', options: ['Light bouncing', 'Light bending between media', 'Light stopping', 'Light reflecting'], correctIndex: 1 },
      { question: 'White light is made of how many colors?', options: ['Five', 'Six', 'Seven', 'Eight'], correctIndex: 2 },
      { question: 'Which lens converges light rays?', options: ['Concave', 'Convex', 'Plano', 'Cylindrical'], correctIndex: 1 },
    ],
  },
  {
    id: 'acids-bases',
    name: 'Acids and Bases',
    keywords: ['acid', 'base', 'ph', 'alkali', 'neutral', 'indicator', 'litmus', 'salt', 'hydrogen', 'hydroxide'],
    englishText:
      'Acids are substances that release hydrogen ions (H⁺) in water and have a pH less than 7. Bases release hydroxide ions (OH⁻) and have a pH greater than 7. A neutral substance has a pH of 7. Indicators like litmus paper change color in acids and bases. Acids turn blue litmus red, and bases turn red litmus blue. When an acid reacts with a base, it forms salt and water (neutralization).',
    simpleExplanation:
      'Acids are sour and have pH below 7. Bases are bitter and have pH above 7. When they react, they form salt and water.',
    importantPoints: [
      'Acids have pH less than 7',
      'Bases have pH greater than 7',
      'Acids turn blue litmus red',
      'Acid + Base = Salt + Water (neutralization)',
    ],
    translations: {
      kannada: {
        text: 'ಆಮ್ಲಗಳು ನೀರಿನಲ್ಲಿ ಹೈಡ್ರೋಜನ್ ಅಯಾನುಗಳನ್ನು ಬಿಡುವ ವಸ್ತುಗಳು ಮತ್ತು 7 ಕ್ಕಿಂತ ಕಡಿಮೆ pH ಹೊಂದಿವೆ. ಪ್ರತ್ಯಾಮ್ಲಗಳು ಹೈಡ್ರಾಕ್ಸೈಡ್ ಅಯಾನುಗಳನ್ನು ಬಿಡುತ್ತವೆ ಮತ್ತು 7 ಕ್ಕಿಂತ ಹೆಚ್ಚು pH ಹೊಂದಿವೆ. ಆಮ್ಲ ಮತ್ತು ಪ್ರತ್ಯಾಮ್ಲ ಪ್ರತಿಕ್ರಿಯಿಸಿದಾಗ ಲವಣ ಮತ್ತು ನೀರು ಉಂಟಾಗುತ್ತದೆ.',
        explanation: 'ಆಮ್ಲಗಳು ಹುಳಿ ರುಚಿಯ ಮತ್ತು 7 ಕ್ಕಿಂತ ಕಡಿಮೆ pH ಹೊಂದಿವೆ. ಪ್ರತ್ಯಾಮ್ಲಗಳು ಕಹಿಯಾಗಿರುತ್ತವೆ ಮತ್ತು 7 ಕ್ಕಿಂತ ಹೆಚ್ಚು pH ಹೊಂದಿವೆ. ಅವು ಪ್ರತಿಕ್ರಿಯಿಸಿದಾಗ ಲವಣ ಮತ್ತು ನೀರು ಉಂಟಾಗುತ್ತದೆ.',
        points: [
          'ಆಮ್ಲಗಳು 7 ಕ್ಕಿಂತ ಕಡಿಮೆ pH ಹೊಂದಿವೆ',
          'ಪ್ರತ್ಯಾಮ್ಲಗಳು 7 ಕ್ಕಿಂತ ಹೆಚ್ಚು pH ಹೊಂದಿವೆ',
          'ಆಮ್ಲಗಳು ನೀಲಿ ಲಿಟ್ಮಸ್ ಅನ್ನು ಕೆಂಪಾಗಿಸುತ್ತವೆ',
          'ಆಮ್ಲ + ಪ್ರತ್ಯಾಮ್ಲ = ಲವಣ + ನೀರು (ತಟಸ್ಥೀಕರಣ)',
        ],
      },
      hindi: {
        text: 'अम्ल पदार्थ हाइड्रोजन आयन जारी करते हैं और उनका pH 7 से कम होता है। क्षार हाइड्रॉक्साइड आयन जारी करते हैं और उनका pH 7 से अधिक होता है। अम्ल और क्षार प्रतिक्रिया करके लवण और जल बनाते हैं (उदासीनीकरण)।',
        explanation: 'अम्ल खट्टे होते हैं और उनका pH 7 से कम होता है। क्षार कड़वे होते हैं और उनका pH 7 से अधिक होता है। वे प्रतिक्रिया करके लवण और जल बनाते हैं।',
        points: [
          'अम्ल का pH 7 से कम होता है',
          'क्षार का pH 7 से अधिक होता है',
          'अम्ल नीले लिटमस को लाल करते हैं',
          'अम्ल + क्षार = लवण + जल (उदासीनीकरण)',
        ],
      },
    },
    questions: [
      { question: 'What pH do acids have?', options: ['Greater than 7', 'Equal to 7', 'Less than 7', 'Equal to 14'], correctIndex: 2 },
      { question: 'What do acids release in water?', options: ['OH⁻ ions', 'H⁺ ions', 'Na⁺ ions', 'Cl⁻ ions'], correctIndex: 1 },
      { question: 'Acid + Base produces?', options: ['Salt + Water', 'Gas + Water', 'Salt + Gas', 'Oil + Water'], correctIndex: 0 },
      { question: 'What color does blue litmus turn in acid?', options: ['Blue', 'Green', 'Red', 'Yellow'], correctIndex: 2 },
      { question: 'What is the pH of a neutral substance?', options: ['0', '7', '14', '1'], correctIndex: 1 },
    ],
  },
];

export function detectChapter(text: string): ChapterData | null {
  const lower = text.toLowerCase();
  let bestMatch: ChapterData | null = null;
  let bestScore = 0;
  for (const chapter of CHAPTERS) {
    let score = 0;
    for (const kw of chapter.keywords) {
      if (lower.includes(kw)) score++;
    }
    if (score > bestScore) {
      bestScore = score;
      bestMatch = chapter;
    }
  }
  return bestScore > 0 ? bestMatch : null;
}
