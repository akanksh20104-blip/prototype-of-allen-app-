import { Home, Wallet, UtensilsCrossed, ClipboardList, Heart } from 'lucide-react';

export type TabId = 'home' | 'explore' | 'create' | 'activity' | 'profile';

export interface TabDef {
  id: TabId;
  label: string;
  icon: typeof Home;
}

export const TABS: TabDef[] = [
  { id: 'home', label: 'Home', icon: Home },
  { id: 'explore', label: 'Finance', icon: Wallet },
  { id: 'create', label: 'Canteen', icon: UtensilsCrossed },
  { id: 'activity', label: 'Issues', icon: ClipboardList },
  { id: 'profile', label: 'Health', icon: Heart },
];
