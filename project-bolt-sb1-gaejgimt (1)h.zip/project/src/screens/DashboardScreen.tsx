import { Award, Flame, BookOpen, Target, TrendingUp, Activity, Zap } from 'lucide-react';
import type { StudentProfile } from '@/types';

interface DashboardScreenProps {
  data: StudentProfile;
}

export default function DashboardScreen({ data }: DashboardScreenProps) {
  const quizzesAttended = data.quizHistory.length;
  const chaptersStudied = data.completedChapters.length;

  const recentActivity = [
    ...data.quizHistory.slice(-3).reverse().map((q) => ({
      type: 'quiz' as const,
      title: q.chapterName,
      detail: `Quiz completed · ${q.correct}/${q.totalQuestions} correct`,
      xp: `+${q.xpEarned} XP`,
    })),
    ...data.savedLessons.slice(-2).reverse().map((l) => ({
      type: 'lesson' as const,
      title: l.chapterName,
      detail: 'Lesson completed',
      xp: '+20 XP',
    })),
  ].slice(0, 5);

  const stats = [
    { label: 'Quizzes Attended', value: quizzesAttended, icon: Target, color: 'text-blue-600', bg: 'bg-blue-50' },
    { label: 'XP Points', value: `${data.xp}`, icon: Zap, color: 'text-amber-600', bg: 'bg-amber-50' },
    { label: 'Chapters Studied', value: chaptersStudied, icon: BookOpen, color: 'text-emerald-600', bg: 'bg-emerald-50' },
    { label: 'Learning Streak', value: `🔥 ${data.streak}`, icon: Flame, color: 'text-rose-600', bg: 'bg-rose-50' },
  ];

  return (
    <div className="px-5 py-4 space-y-5 animate-fade-in">
      <h2 className="text-lg font-bold text-slate-900">Your Dashboard</h2>

      {/* Stat cards */}
      <div className="grid grid-cols-2 gap-3">
        {stats.map((s) => {
          const Icon = s.icon;
          return (
            <div key={s.label} className="bg-white rounded-2xl p-4 border border-slate-100 shadow-sm">
              <div className={`w-10 h-10 rounded-xl ${s.bg} flex items-center justify-center mb-2.5`}>
                <Icon size={20} className={s.color} />
              </div>
              <p className="text-2xl font-bold text-slate-900 leading-none">{s.value}</p>
              <p className="text-[11px] text-slate-400 mt-1">{s.label}</p>
            </div>
          );
        })}
      </div>

      {/* XP system info */}
      <div className="bg-gradient-to-br from-amber-50 to-orange-50 rounded-2xl p-4 border border-amber-100">
        <div className="flex items-center gap-2 mb-2">
          <Award size={16} className="text-amber-600" />
          <span className="text-sm font-bold text-slate-700">How you earn XP</span>
        </div>
        <div className="space-y-1">
          {[
            { label: 'Lesson completed', xp: '+20 XP' },
            { label: 'Correct quiz answer', xp: '+20 XP' },
            { label: 'Quiz completion bonus', xp: '+20 XP' },
            { label: 'Perfect quiz bonus', xp: '+50 XP' },
          ].map((item) => (
            <div key={item.label} className="flex items-center justify-between">
              <span className="text-xs text-slate-500">{item.label}</span>
              <span className="text-xs font-bold text-amber-600">{item.xp}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Recent activity */}
      <div>
        <div className="flex items-center gap-2 mb-3">
          <Activity size={16} className="text-slate-700" />
          <h3 className="text-base font-bold text-slate-900">Recent Activity</h3>
        </div>
        {recentActivity.length === 0 ? (
          <p className="text-sm text-slate-400 text-center py-4">No activity yet. Start learning!</p>
        ) : (
          <div className="space-y-2.5">
            {recentActivity.map((act, i) => (
              <div key={i} className="bg-white rounded-2xl p-3.5 border border-slate-100 shadow-sm flex items-center gap-3">
                <div className={`w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 ${
                  act.type === 'quiz' ? 'bg-blue-50' : 'bg-emerald-50'
                }`}>
                  {act.type === 'quiz' ? <Target size={17} className="text-blue-600" /> : <BookOpen size={17} className="text-emerald-600" />}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold text-slate-800">{act.title}</p>
                  <p className="text-[11px] text-slate-400 mt-0.5">{act.detail}</p>
                </div>
                <span className="text-xs font-bold text-amber-600 flex-shrink-0">{act.xp}</span>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Streak info */}
      <div className="flex items-start gap-2.5 bg-rose-50 rounded-2xl p-3.5 border border-rose-100">
        <TrendingUp size={18} className="text-rose-600 flex-shrink-0 mt-0.5" />
        <p className="text-xs text-rose-700 leading-relaxed">
          You're on a {data.streak}-day streak! Complete at least one activity daily to keep it going.
        </p>
      </div>
    </div>
  );
}
