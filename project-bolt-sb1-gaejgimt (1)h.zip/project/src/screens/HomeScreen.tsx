import { useState } from 'react';
import {
  TrendingUp,
  Clock,
  ArrowUpRight,
  Flame,
  Bookmark,
  BookOpen,
  FileText,
  Target,
  Calendar,
  ChevronRight,
  Languages,
  Library,
  GraduationCap,
  Newspaper,
  Star,
  ScanText,
  Brain,
} from 'lucide-react';
import PhotoTranslator from '@/components/PhotoTranslator';
import QuizMe from '@/components/QuizMe';

interface HomeScreenProps {
  onExplore: () => void;
  language: string;
  course: string;
}

type ClassId = '8th' | '9th' | '10th' | '11th' | '12th';

interface ClassLevel {
  id: ClassId;
  name: string;
  fullName: string;
  color: string;
}

const CLASS_LEVELS: ClassLevel[] = [
  { id: '8th', name: '8th', fullName: 'Foundation', color: 'from-sky-500 to-blue-600' },
  { id: '9th', name: '9th', fullName: 'Foundation', color: 'from-emerald-500 to-teal-600' },
  { id: '10th', name: '10th', fullName: 'Board Prep', color: 'from-amber-500 to-orange-600' },
  { id: '11th', name: '11th', fullName: 'JEE/NEET', color: 'from-rose-500 to-pink-600' },
  { id: '12th', name: '12th', fullName: 'JEE/NEET', color: 'from-violet-500 to-purple-600' },
];

interface TrendingItem { id: number; subject: string; title: string; reads: string; hot: boolean }
interface RecentItem { id: number; title: string; progress: number; time: string }

const MATERIAL: Record<ClassId, { trending: TrendingItem[]; recent: RecentItem[] }> = {
  '8th': {
    trending: [
      { id: 1, subject: 'Maths', title: 'Rational Numbers — Basics', reads: '12.1k', hot: true },
      { id: 2, subject: 'Science', title: 'Crop Production & Management', reads: '9.7k', hot: true },
      { id: 3, subject: 'English', title: 'Grammar: Tenses & Modals', reads: '8.3k', hot: false },
      { id: 4, subject: 'SST', title: 'Our Pasts — Medieval India', reads: '6.9k', hot: false },
    ],
    recent: [
      { id: 1, title: 'Maths: Linear Equations Practice', progress: 72, time: '10 min left' },
      { id: 2, title: 'Science: Microorganisms Quiz', progress: 40, time: '15 min left' },
      { id: 3, title: 'English: Reading Comprehension', progress: 100, time: 'Completed' },
    ],
  },
  '9th': {
    trending: [
      { id: 1, subject: 'Maths', title: 'Polynomials — Factor Theorem', reads: '18.2k', hot: true },
      { id: 2, subject: 'Science', title: 'Matter in Our Surroundings', reads: '15.5k', hot: true },
      { id: 3, subject: 'English', title: 'Literature: The Fun They Had', reads: '11.4k', hot: false },
      { id: 4, subject: 'SST', title: 'French Revolution — Causes', reads: '9.8k', hot: false },
    ],
    recent: [
      { id: 1, title: 'Maths: Number Systems Practice Set 3', progress: 55, time: '8 min left' },
      { id: 2, title: 'Science: Atoms & Molecules', progress: 30, time: '18 min left' },
      { id: 3, title: 'SST: Democratic Rights', progress: 100, time: 'Completed' },
    ],
  },
  '10th': {
    trending: [
      { id: 1, subject: 'Maths', title: "Real Numbers — Euclid's Lemma", reads: '24.5k', hot: true },
      { id: 2, subject: 'Science', title: 'Chemical Reactions & Equations', reads: '21.8k', hot: true },
      { id: 3, subject: 'English', title: 'First Flight — Prose Summary', reads: '16.2k', hot: false },
      { id: 4, subject: 'SST', title: 'Nationalism in India', reads: '14.1k', hot: false },
    ],
    recent: [
      { id: 1, title: 'Maths: Quadratic Equations Mock Test', progress: 80, time: '6 min left' },
      { id: 2, title: 'Science: Light Reflection & Refraction', progress: 45, time: '12 min left' },
      { id: 3, title: 'SST: Power Sharing Complete', progress: 100, time: 'Completed' },
    ],
  },
  '11th': {
    trending: [
      { id: 1, subject: 'Physics', title: 'Kinematics — Motion in a Straight Line', reads: '28.3k', hot: true },
      { id: 2, subject: 'Chemistry', title: 'Atomic Structure — Quantum Numbers', reads: '22.7k', hot: true },
      { id: 3, subject: 'Maths', title: 'Sets, Relations & Functions', reads: '19.1k', hot: false },
      { id: 4, subject: 'Biology', title: 'Cell: The Unit of Life', reads: '15.6k', hot: false },
    ],
    recent: [
      { id: 1, title: 'Physics: Laws of Motion Practice Set 2', progress: 68, time: '11 min left' },
      { id: 2, title: 'Chemistry: Chemical Bonding', progress: 42, time: '20 min left' },
      { id: 3, title: 'Maths: Trigonometry Basics', progress: 100, time: 'Completed' },
    ],
  },
  '12th': {
    trending: [
      { id: 1, subject: 'Physics', title: "Electrostatics — Gauss's Law", reads: '31.5k', hot: true },
      { id: 2, subject: 'Chemistry', title: 'Solid State — Crystal Lattice', reads: '26.4k', hot: true },
      { id: 3, subject: 'Maths', title: 'Continuity & Differentiability', reads: '23.2k', hot: false },
      { id: 4, subject: 'Biology', title: "Genetics — Mendel's Laws", reads: '18.7k', hot: false },
    ],
    recent: [
      { id: 1, title: 'Physics: Current Electricity Mock Test 4', progress: 75, time: '9 min left' },
      { id: 2, title: 'Chemistry: Solutions & Colligative', progress: 50, time: '14 min left' },
      { id: 3, title: 'Maths: Integrals Practice', progress: 100, time: 'Completed' },
    ],
  },
};

const UPCOMING_EXAMS = [
  { name: 'Class 10 Board Exam', date: 'Mar 5', days: '160 days', color: 'bg-amber-50 text-amber-600' },
  { name: 'JEE Main Session 1', date: 'Jan 24', days: '120 days', color: 'bg-blue-50 text-blue-600' },
  { name: 'NEET UG 2026', date: 'May 3', days: '218 days', color: 'bg-rose-50 text-rose-600' },
];

interface ExamRec { name: string; medium: string; note: string }
interface MaterialRec { title: string; type: string; desc: string }

interface LanguageRec {
  label: string;
  flag: string;
  exams: ExamRec[];
  materials: MaterialRec[];
}

const LANGUAGE_RECS: Record<string, LanguageRec> = {
  English: {
    label: 'English', flag: 'EN',
    exams: [
      { name: 'CBSE Board (English)', medium: 'English medium', note: 'Class 10 & 12 board exams' },
      { name: 'JEE Main/Advanced', medium: 'English medium', note: 'Physics, Chemistry, Maths in English' },
      { name: 'NEET UG', medium: 'English medium', note: 'Physics, Chemistry, Biology in English' },
    ],
    materials: [
      { title: 'The Hindu Editorial Analysis', type: 'Daily', desc: 'Vocabulary & comprehension builder' },
      { title: 'NCERT Summary (Eng)', type: 'PDF', desc: 'Class 6–12 one-line notes' },
      { title: 'English Grammar Quick Capsule', type: 'PDF', desc: 'For board & competitive English' },
    ],
  },
  Hindi: {
    label: 'Hindi', flag: 'HI',
    exams: [
      { name: 'CBSE Board (Hindi)', medium: 'Hindi medium', note: 'Class 10 & 12 in Hindi medium' },
      { name: 'JEE Main (Hindi)', medium: 'Hindi medium', note: 'Available in Hindi' },
      { name: 'NEET (Hindi)', medium: 'Hindi medium', note: 'Question papers in Hindi' },
    ],
    materials: [
      { title: 'Dainik Jagran Editorial', type: 'Daily', desc: 'Hindi vocabulary & current affairs' },
      { title: 'NCERT Saar (Hindi)', type: 'PDF', desc: 'Class 6–12 Hindi summary notes' },
      { title: 'Samanya Hindi Capsule', type: 'PDF', desc: 'Grammar & sandhi for exams' },
    ],
  },
  Gujarati: {
    label: 'Gujarati', flag: 'GU',
    exams: [
      { name: 'GSEB Board (Gujarati)', medium: 'Gujarati medium', note: 'Gujarat board exams in Gujarati' },
      { name: 'GUJCET', medium: 'Gujarati medium', note: 'Gujarat common entrance test' },
      { name: 'JEE Main (Guj)', medium: 'Gujarati medium', note: 'Available in Gujarati' },
    ],
    materials: [
      { title: 'Gujarat Samachar Editorial', type: 'Daily', desc: 'Gujarati current affairs' },
      { title: 'Gujarati Grammar Capsule', type: 'PDF', desc: 'Sandhi, samas & alankar' },
      { title: 'GSEB Quick Notes', type: 'PDF', desc: 'Gujarat board specific notes' },
    ],
  },
  Marathi: {
    label: 'Marathi', flag: 'MR',
    exams: [
      { name: 'MSBSHSE Board (Marathi)', medium: 'Marathi medium', note: 'Maharashtra board in Marathi' },
      { name: 'MHT-CET', medium: 'Marathi medium', note: 'Maharashtra common entrance test' },
      { name: 'JEE Main (Marathi)', medium: 'Marathi medium', note: 'Available in Marathi' },
    ],
    materials: [
      { title: 'Loksatta Editorial', type: 'Daily', desc: 'Marathi vocabulary & analysis' },
      { title: 'Marathi Grammar Capsule', type: 'PDF', desc: 'Sandhi, samas & grammar rules' },
      { title: 'MSBSHSE Quick Notes', type: 'PDF', desc: 'Maharashtra board specific' },
    ],
  },
  Tamil: {
    label: 'Tamil', flag: 'TA',
    exams: [
      { name: 'TN Board (Tamil)', medium: 'Tamil medium', note: 'Tamil Nadu board exams' },
      { name: 'JEE Main (Tamil)', medium: 'Tamil medium', note: 'Available in Tamil' },
      { name: 'NEET (Tamil)', medium: 'Tamil medium', note: 'Question papers in Tamil' },
    ],
    materials: [
      { title: 'Dinamani Editorial', type: 'Daily', desc: 'Tamil current affairs' },
      { title: 'Tamil Grammar Capsule', type: 'PDF', desc: 'Ilakkanam & ilakkiya grammar' },
      { title: 'TN Board Quick Notes', type: 'PDF', desc: 'Tamil Nadu specific notes' },
    ],
  },
  Telugu: {
    label: 'Telugu', flag: 'TE',
    exams: [
      { name: 'AP/TS Board (Telugu)', medium: 'Telugu medium', note: 'Andhra/Telangana board exams' },
      { name: 'AP EAMCET', medium: 'Telugu medium', note: 'Andhra Pradesh entrance test' },
      { name: 'JEE Main (Telugu)', medium: 'Telugu medium', note: 'Available in Telugu' },
    ],
    materials: [
      { title: 'Eenadu Editorial', type: 'Daily', desc: 'Telugu current affairs' },
      { title: 'Telugu Grammar Capsule', type: 'PDF', desc: 'Sandhi & vibhakti grammar' },
      { title: 'AP/TS Board Quick Notes', type: 'PDF', desc: 'State board specific notes' },
    ],
  },
  Bengali: {
    label: 'Bengali', flag: 'BN',
    exams: [
      { name: 'WBBSE Board (Bengali)', medium: 'Bengali medium', note: 'West Bengal board in Bengali' },
      { name: 'WBJEE', medium: 'Bengali medium', note: 'West Bengal joint entrance' },
      { name: 'JEE Main (Bengali)', medium: 'Bengali medium', note: 'Available in Bengali' },
    ],
    materials: [
      { title: 'Anandabazar Editorial', type: 'Daily', desc: 'Bengali current affairs' },
      { title: 'Bengali Grammar Capsule', type: 'PDF', desc: 'Sandhi & karak grammar' },
      { title: 'WBBSE Quick Notes', type: 'PDF', desc: 'West Bengal board specific' },
    ],
  },
};

interface BookRec { title: string; author: string; subject: string; rating: number }

const COURSE_BOOKS: Record<string, BookRec[]> = {
  'JEE Advanced — 2 Year': [
    { title: 'Concepts of Physics (Vol 1 & 2)', author: 'H.C. Verma', subject: 'Physics', rating: 4.9 },
    { title: 'Organic Chemistry', author: 'Morrison & Boyd', subject: 'Chemistry', rating: 4.7 },
    { title: 'IIT Mathematics', author: 'M.L. Khanna', subject: 'Maths', rating: 4.8 },
    { title: 'Problems in General Physics', author: 'I.E. Irodov', subject: 'Physics', rating: 4.8 },
  ],
  'JEE Main — 1 Year': [
    { title: 'NCERT Physics (Class 11 & 12)', author: 'NCERT', subject: 'Physics', rating: 4.6 },
    { title: 'Modern Approach to Chemical Calculations', author: 'R.C. Mukerjee', subject: 'Chemistry', rating: 4.7 },
    { title: 'Objective Mathematics', author: 'R.D. Sharma', subject: 'Maths', rating: 4.6 },
    { title: 'Concepts of Physics (Vol 1)', author: 'H.C. Verma', subject: 'Physics', rating: 4.9 },
  ],
  'NEET — 2 Year': [
    { title: 'Biology (Vol 1 & 2)', author: 'Trueman', subject: 'Biology', rating: 4.9 },
    { title: 'Concepts of Physics (Vol 1 & 2)', author: 'H.C. Verma', subject: 'Physics', rating: 4.9 },
    { title: 'Organic Chemistry', author: 'Morrison & Boyd', subject: 'Chemistry', rating: 4.7 },
    { title: 'NCERT Biology (Class 11 & 12)', author: 'NCERT', subject: 'Biology', rating: 4.8 },
  ],
  'NEET — 1 Year': [
    { title: 'NCERT Biology (Class 11 & 12)', author: 'NCERT', subject: 'Biology', rating: 4.8 },
    { title: 'Concepts of Physics (Vol 1)', author: 'H.C. Verma', subject: 'Physics', rating: 4.9 },
    { title: 'Modern Approach to Chemical Calculations', author: 'R.C. Mukerjee', subject: 'Chemistry', rating: 4.7 },
    { title: 'Biology (Vol 1)', author: 'Trueman', subject: 'Biology', rating: 4.9 },
  ],
  'Foundation 8th': [
    { title: 'NCERT Science (Class 8)', author: 'NCERT', subject: 'Science', rating: 4.5 },
    { title: 'NCERT Maths (Class 8)', author: 'NCERT', subject: 'Maths', rating: 4.5 },
    { title: 'Foundation Science Physics 8', author: 'MTG', subject: 'Science', rating: 4.4 },
    { title: 'Foundation Mathematics 8', author: 'MTG', subject: 'Maths', rating: 4.4 },
  ],
  'Foundation 9th': [
    { title: 'NCERT Science (Class 9)', author: 'NCERT', subject: 'Science', rating: 4.6 },
    { title: 'NCERT Maths (Class 9)', author: 'NCERT', subject: 'Maths', rating: 4.6 },
    { title: 'Foundation Science Physics 9', author: 'MTG', subject: 'Science', rating: 4.5 },
    { title: 'Foundation Mathematics 9', author: 'MTG', subject: 'Maths', rating: 4.5 },
  ],
  'Foundation 10th': [
    { title: 'NCERT Science (Class 10)', author: 'NCERT', subject: 'Science', rating: 4.7 },
    { title: 'NCERT Maths (Class 10)', author: 'NCERT', subject: 'Maths', rating: 4.7 },
    { title: 'All in One Science 10', author: 'Arihant', subject: 'Science', rating: 4.5 },
    { title: 'All in One Maths 10', author: 'Arihant', subject: 'Maths', rating: 4.5 },
  ],
  'Class 11 Science': [
    { title: 'NCERT Physics (Class 11)', author: 'NCERT', subject: 'Physics', rating: 4.6 },
    { title: 'NCERT Chemistry (Class 11)', author: 'NCERT', subject: 'Chemistry', rating: 4.6 },
    { title: 'NCERT Maths (Class 11)', author: 'NCERT', subject: 'Maths', rating: 4.6 },
    { title: 'NCERT Biology (Class 11)', author: 'NCERT', subject: 'Biology', rating: 4.7 },
  ],
  'Class 12 Science': [
    { title: 'NCERT Physics (Class 12)', author: 'NCERT', subject: 'Physics', rating: 4.7 },
    { title: 'NCERT Chemistry (Class 12)', author: 'NCERT', subject: 'Chemistry', rating: 4.7 },
    { title: 'NCERT Maths (Class 12)', author: 'NCERT', subject: 'Maths', rating: 4.7 },
    { title: 'NCERT Biology (Class 12)', author: 'NCERT', subject: 'Biology', rating: 4.8 },
  ],
};

export default function HomeScreen({ onExplore, language, course }: HomeScreenProps) {
  const [activeClass, setActiveClass] = useState<ClassId>('10th');
  const [photoTranslatorOpen, setPhotoTranslatorOpen] = useState(false);
  const [quizMeOpen, setQuizMeOpen] = useState(false);
  const data = MATERIAL[activeClass];
  const activeClassObj = CLASS_LEVELS.find((c) => c.id === activeClass)!;
  const langRec = LANGUAGE_RECS[language] ?? LANGUAGE_RECS['English'];
  const courseBooks = COURSE_BOOKS[course] ?? COURSE_BOOKS['JEE Advanced — 2 Year'];

  return (
    <div className="px-5 py-4 space-y-6 animate-fade-in">
      {/* Hero card */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-blue-700 via-blue-600 to-indigo-600 p-6 shadow-xl shadow-blue-500/20">
        <div className="absolute -top-8 -right-8 w-32 h-32 rounded-full bg-white/10" />
        <div className="absolute -bottom-12 -right-4 w-24 h-24 rounded-full bg-white/5" />
        <div className="relative">
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-white/20 text-white text-[11px] font-semibold backdrop-blur-sm">
            <Flame size={12} /> Daily Practice
          </span>
          <h2 className="mt-3 text-white text-xl font-bold leading-snug">
            Class {activeClassObj.name} — {activeClassObj.fullName}
          </h2>
          <p className="mt-1.5 text-blue-100 text-sm">
            {data.trending[0].subject}: {data.trending[0].title}
          </p>
          <div className="mt-4 flex items-center gap-3">
            <button
              onClick={onExplore}
              className="px-4 py-2 rounded-xl bg-white text-blue-600 text-sm font-semibold flex items-center gap-1.5 active:scale-95 transition-transform"
            >
              Start studying <ArrowUpRight size={15} />
            </button>
            <button className="px-4 py-2 rounded-xl bg-white/15 text-white text-sm font-medium backdrop-blur-sm active:scale-95 transition-transform flex items-center gap-1.5">
              <Bookmark size={15} /> Save
            </button>
          </div>
        </div>
      </div>

      {/* Photo Translator card */}
      <button
        onClick={() => setPhotoTranslatorOpen(true)}
        className="w-full relative overflow-hidden rounded-2xl bg-gradient-to-br from-sky-600 to-blue-700 p-4 shadow-lg shadow-blue-500/20 text-left active:scale-[0.98] transition-transform"
      >
        <div className="absolute -top-6 -right-6 w-20 h-20 rounded-full bg-white/10" />
        <div className="relative flex items-center gap-3">
          <div className="w-11 h-11 rounded-xl bg-white/20 flex items-center justify-center flex-shrink-0">
            <ScanText size={22} className="text-white" />
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-white font-bold text-sm">Translate from Photo</p>
            <p className="text-blue-100 text-[11px] mt-0.5">Scan text from any image & translate it</p>
          </div>
          <ArrowUpRight size={18} className="text-white/80 flex-shrink-0" />
        </div>
      </button>

      {/* Quiz Me card */}
      <button
        onClick={() => setQuizMeOpen(true)}
        className="w-full relative overflow-hidden rounded-2xl bg-gradient-to-br from-emerald-600 to-teal-700 p-4 shadow-lg shadow-emerald-500/20 text-left active:scale-[0.98] transition-transform"
      >
        <div className="absolute -top-6 -right-6 w-20 h-20 rounded-full bg-white/10" />
        <div className="relative flex items-center gap-3">
          <div className="w-11 h-11 rounded-xl bg-white/20 flex items-center justify-center flex-shrink-0">
            <Brain size={22} className="text-white" />
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-white font-bold text-sm">Quiz Me</p>
            <p className="text-emerald-100 text-[11px] mt-0.5">Pick a topic, set difficulty & test yourself</p>
          </div>
          <ArrowUpRight size={18} className="text-white/80 flex-shrink-0" />
        </div>
      </button>

      {/* Language + course recommendations banner */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-violet-600 to-purple-600 p-4 shadow-lg shadow-purple-500/20">
        <div className="absolute -top-6 -right-6 w-20 h-20 rounded-full bg-white/10" />
        <div className="relative flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center flex-shrink-0">
            <Languages size={20} className="text-white" />
          </div>
          <div className="flex-1">
            <p className="text-white font-bold text-sm">Recommendations for {course}</p>
            <p className="text-violet-100 text-[11px] mt-0.5">Books in {langRec.label} · Exams & study material</p>
          </div>
          <span className="text-white/80 text-xs font-bold bg-white/15 px-2.5 py-1 rounded-full">{langRec.flag}</span>
        </div>
      </div>

      {/* Course-specific recommended books */}
      <div>
        <div className="flex items-center gap-2 mb-1">
          <Library size={16} className="text-slate-700" />
          <h3 className="text-base font-bold text-slate-900">Books for your course</h3>
        </div>
        <p className="text-xs text-slate-400 mb-3">{course}</p>
        <div className="space-y-2.5">
          {courseBooks.map((book, i) => (
            <div
              key={i}
              className="bg-white rounded-2xl p-3.5 border border-slate-100 shadow-sm flex items-center gap-3 active:scale-[0.98] transition-transform cursor-pointer"
            >
              <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-blue-100 to-indigo-100 flex items-center justify-center flex-shrink-0">
                <BookOpen size={18} className="text-blue-600" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold text-slate-800 truncate">{book.title}</p>
                <p className="text-[11px] text-slate-400 mt-0.5">{book.author} · {book.subject}</p>
              </div>
              <div className="flex items-center gap-1 flex-shrink-0">
                <Star size={12} className="text-amber-400 fill-amber-400" />
                <span className="text-[11px] font-medium text-slate-600">{book.rating}</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Exams in selected language */}
      <div>
        <div className="flex items-center gap-2 mb-3">
          <GraduationCap size={16} className="text-slate-700" />
          <h3 className="text-base font-bold text-slate-900">Exams in {langRec.label} medium</h3>
        </div>
        <div className="grid grid-cols-1 gap-2.5">
          {langRec.exams.map((exam, i) => (
            <div
              key={i}
              className="bg-white rounded-2xl p-3.5 border border-slate-100 shadow-sm flex items-center gap-3"
            >
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-100 to-teal-100 flex items-center justify-center flex-shrink-0">
                <Target size={18} className="text-emerald-600" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold text-slate-800 truncate">{exam.name}</p>
                <p className="text-[11px] text-slate-400 mt-0.5">{exam.note}</p>
              </div>
              <span className="text-[10px] font-semibold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-full flex-shrink-0">
                {exam.medium}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Study materials in selected language */}
      <div>
        <div className="flex items-center gap-2 mb-3">
          <Newspaper size={16} className="text-slate-700" />
          <h3 className="text-base font-bold text-slate-900">Study material in {langRec.label}</h3>
        </div>
        <div className="space-y-2.5">
          {langRec.materials.map((mat, i) => (
            <div
              key={i}
              className="bg-white rounded-2xl p-3.5 border border-slate-100 shadow-sm flex items-center gap-3 active:scale-[0.98] transition-transform cursor-pointer"
            >
              <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-amber-100 to-orange-100 flex items-center justify-center flex-shrink-0">
                <FileText size={18} className="text-amber-600" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold text-slate-800 truncate">{mat.title}</p>
                <p className="text-[11px] text-slate-400 mt-0.5">{mat.desc}</p>
              </div>
              <span className="text-[10px] font-semibold text-blue-600 bg-blue-50 px-2 py-0.5 rounded-full flex-shrink-0">
                {mat.type}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Class level selector chips */}
      <div>
        <h3 className="text-base font-bold text-slate-900 mb-3">Choose your class</h3>
        <div className="flex gap-2 overflow-x-auto no-scrollbar -mx-5 px-5">
          {CLASS_LEVELS.map((cls) => {
            const isActive = activeClass === cls.id;
            return (
              <button
                key={cls.id}
                onClick={() => setActiveClass(cls.id)}
                className={`flex-shrink-0 flex items-center gap-2 px-4 py-2.5 rounded-2xl transition-all ${
                  isActive
                    ? `bg-gradient-to-br ${cls.color} text-white shadow-lg shadow-blue-500/20`
                    : 'bg-white text-slate-600 border border-slate-200'
                }`}
              >
                <div className="text-left">
                  <p className="text-sm font-semibold leading-none">Class {cls.name}</p>
                  <p className={`text-[10px] mt-0.5 ${isActive ? 'text-white/70' : 'text-slate-400'}`}>
                    {cls.fullName}
                  </p>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Study stats */}
      <div className="grid grid-cols-3 gap-3">
        {[
          { label: 'Streak', value: '14', unit: 'days', color: 'text-orange-500', bg: 'bg-orange-50' },
          { label: 'Studied', value: '38', unit: 'topics', color: 'text-blue-600', bg: 'bg-blue-50' },
          { label: 'Score', value: '72', unit: '% avg', color: 'text-emerald-600', bg: 'bg-emerald-50' },
        ].map((s) => (
          <div key={s.label} className="bg-white rounded-2xl p-3.5 border border-slate-100 shadow-sm">
            <div className={`w-8 h-8 rounded-lg ${s.bg} flex items-center justify-center mb-2`}>
              <TrendingUp size={16} className={s.color} />
            </div>
            <p className="text-lg font-bold text-slate-900 leading-none">{s.value}</p>
            <p className="text-[11px] text-slate-400 mt-0.5">
              {s.unit} · {s.label}
            </p>
          </div>
        ))}
      </div>

      {/* Upcoming exams */}
      <div>
        <div className="flex items-center gap-2 mb-3">
          <Calendar size={16} className="text-slate-700" />
          <h3 className="text-base font-bold text-slate-900">Upcoming exams</h3>
        </div>
        <div className="space-y-2.5">
          {UPCOMING_EXAMS.map((exam) => (
            <div
              key={exam.name}
              className="bg-white rounded-2xl p-3.5 border border-slate-100 shadow-sm flex items-center gap-3"
            >
              <div className={`w-12 h-12 rounded-xl ${exam.color} flex flex-col items-center justify-center flex-shrink-0`}>
                <span className="text-[10px] font-medium leading-none">{exam.date.split(' ')[0]}</span>
                <span className="text-sm font-bold leading-none mt-0.5">{exam.date.split(' ')[1]}</span>
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold text-slate-800 truncate">{exam.name}</p>
                <p className="text-[11px] text-slate-400 mt-0.5">{exam.days} away</p>
              </div>
              <ChevronRight size={18} className="text-slate-300" />
            </div>
          ))}
        </div>
      </div>

      {/* Trending study material */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-base font-bold text-slate-900">Trending in Class {activeClassObj.name}</h3>
          <button onClick={onExplore} className="text-xs font-semibold text-blue-600">
            See all
          </button>
        </div>
        <div className="space-y-2.5">
          {data.trending.map((item: TrendingItem) => (
            <div
              key={item.id}
              className="bg-white rounded-2xl p-3.5 border border-slate-100 shadow-sm flex items-center gap-3 active:scale-[0.98] transition-transform cursor-pointer"
            >
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-slate-100 to-slate-200 flex items-center justify-center flex-shrink-0">
                <span className="text-[10px] font-bold text-slate-500">{item.subject.slice(0, 4)}</span>
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold text-slate-800 truncate">{item.title}</p>
                <p className="text-[11px] text-slate-400 mt-0.5">
                  {item.subject} · {item.reads} reads
                </p>
              </div>
              {item.hot && (
                <span className="flex items-center gap-0.5 text-[10px] font-semibold text-orange-500 bg-orange-50 px-2 py-0.5 rounded-full">
                  <Flame size={10} /> Hot
                </span>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Continue studying */}
      <div>
        <h3 className="text-base font-bold text-slate-900 mb-3">Continue studying</h3>
        <div className="space-y-2.5">
          {data.recent.map((item: RecentItem) => (
            <div key={item.id} className="bg-white rounded-2xl p-3.5 border border-slate-100 shadow-sm">
              <div className="flex items-center justify-between mb-2">
                <p className="text-sm font-semibold text-slate-800 truncate pr-2">{item.title}</p>
                <span className="flex items-center gap-1 text-[11px] text-slate-400 flex-shrink-0">
                  <Clock size={11} /> {item.time}
                </span>
              </div>
              <div className="h-1.5 rounded-full bg-slate-100 overflow-hidden">
                <div
                  className={`h-full rounded-full ${item.progress === 100 ? 'bg-emerald-500' : 'bg-blue-500'}`}
                  style={{ width: `${item.progress}%` }}
                />
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Photo Translator overlay */}
      {photoTranslatorOpen && (
        <PhotoTranslator onClose={() => setPhotoTranslatorOpen(false)} />
      )}

      {/* Quiz Me overlay */}
      {quizMeOpen && (
        <QuizMe onClose={() => setQuizMeOpen(false)} />
      )}
    </div>
  );
}
