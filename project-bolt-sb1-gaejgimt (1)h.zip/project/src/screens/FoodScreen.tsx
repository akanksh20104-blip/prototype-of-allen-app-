import { useState } from 'react';
import { Utensils, QrCode, TrendingDown, X, Check, Wallet, PieChart, Calendar } from 'lucide-react';
import type { StudentProfile } from '@/types';
import { addWalletTransaction } from '@/hooks/useStudentData';

interface FoodScreenProps {
  data: StudentProfile;
  setData: (d: StudentProfile) => void;
}

const FOOD_ITEMS = [
  { name: 'School Canteen', defaultAmount: 50 },
  { name: 'Lunch', defaultAmount: 80 },
  { name: 'Juice', defaultAmount: 30 },
  { name: 'Snack', defaultAmount: 40 },
  { name: 'Breakfast', defaultAmount: 60 },
  { name: 'Tea/Coffee', defaultAmount: 15 },
];

export default function FoodScreen({ data, setData }: FoodScreenProps) {
  const [showModal, setShowModal] = useState(false);
  const [selectedItem, setSelectedItem] = useState(FOOD_ITEMS[0]);
  const [amount, setAmount] = useState(50);
  const [payToast, setPayToast] = useState(false);
  const [paidAmount, setPaidAmount] = useState(0);

  const foodTransactions = data.walletTransactions
    .filter((t) => t.category === 'food' && t.type === 'debit')
    .reverse();

  const totalSpent = data.foodSpentThisMonth;
  const remainingBudget = data.foodBudget - totalSpent;
  const budgetPercent = Math.min(100, Math.round((totalSpent / data.foodBudget) * 100));
  const avgDaily = foodTransactions.length > 0 ? Math.round(totalSpent / 30) : 0;

  // Most common category
  const categoryCount: Record<string, number> = {};
  foodTransactions.forEach((t) => {
    categoryCount[t.title] = (categoryCount[t.title] ?? 0) + 1;
  });
  const mostCommon = Object.entries(categoryCount).sort((a, b) => b[1] - a[1])[0]?.[0] ?? '—';

  const handlePay = () => {
    if (amount <= 0 || amount > data.walletBalance) return;
    setData(
      addWalletTransaction(data, {
        type: 'debit',
        category: 'food',
        title: selectedItem.name,
        amount,
        date: new Date().toISOString().split('T')[0],
      }),
    );
    setPaidAmount(amount);
    setShowModal(false);
    setPayToast(true);
    setTimeout(() => setPayToast(false), 3000);
  };

  return (
    <div className="px-5 py-4 space-y-5 animate-fade-in">
      {/* Balance */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-blue-700 via-blue-600 to-indigo-600 p-5 shadow-xl shadow-blue-500/20">
        <div className="absolute -top-8 -right-8 w-32 h-32 rounded-full bg-white/10" />
        <div className="relative">
          <div className="flex items-center gap-2">
            <Wallet size={18} className="text-white" />
            <span className="text-white/80 text-xs font-semibold uppercase tracking-wide">Current Balance</span>
          </div>
          <p className="text-white text-3xl font-bold mt-2">₹{data.walletBalance.toLocaleString('en-IN')}</p>
        </div>
      </div>

      {/* Food spending summary */}
      <div className="grid grid-cols-2 gap-3">
        <div className="bg-white rounded-2xl p-4 border border-slate-100 shadow-sm">
          <div className="w-8 h-8 rounded-lg bg-rose-50 flex items-center justify-center mb-2">
            <TrendingDown size={16} className="text-rose-600" />
          </div>
          <p className="text-xl font-bold text-slate-900 leading-none">₹{totalSpent}</p>
          <p className="text-[11px] text-slate-400 mt-1">Spent this month</p>
        </div>
        <div className="bg-white rounded-2xl p-4 border border-slate-100 shadow-sm">
          <div className="w-8 h-8 rounded-lg bg-emerald-50 flex items-center justify-center mb-2">
            <Wallet size={16} className="text-emerald-600" />
          </div>
          <p className="text-xl font-bold text-slate-900 leading-none">₹{remainingBudget}</p>
          <p className="text-[11px] text-slate-400 mt-1">Remaining budget</p>
        </div>
      </div>

      {/* Budget progress bar */}
      <div className="bg-white rounded-2xl p-4 border border-slate-100 shadow-sm">
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm font-semibold text-slate-700">Monthly Food Budget</span>
          <span className="text-xs text-slate-400">₹{totalSpent} / ₹{data.foodBudget}</span>
        </div>
        <div className="h-3 rounded-full bg-slate-100 overflow-hidden">
          <div
            className={`h-full rounded-full transition-all ${budgetPercent > 80 ? 'bg-rose-500' : 'bg-blue-500'}`}
            style={{ width: `${budgetPercent}%` }}
          />
        </div>
        <p className="text-[11px] text-slate-400 mt-1.5">{budgetPercent}% used</p>
      </div>

      {/* Spending analytics */}
      <div className="bg-white rounded-2xl p-4 border border-slate-100 shadow-sm">
        <div className="flex items-center gap-2 mb-3">
          <PieChart size={16} className="text-blue-600" />
          <h3 className="text-sm font-bold text-slate-700">Spending Analytics</h3>
        </div>
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs text-slate-500">Total spent on food</span>
            <span className="text-sm font-semibold text-slate-700">₹{totalSpent}</span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-xs text-slate-500">Average daily spend</span>
            <span className="text-sm font-semibold text-slate-700">₹{avgDaily}</span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-xs text-slate-500">Most common category</span>
            <span className="text-sm font-semibold text-slate-700">{mostCommon}</span>
          </div>
        </div>
      </div>

      {/* Simulated QR Payment */}
      <button
        onClick={() => setShowModal(true)}
        className="w-full py-4 rounded-2xl bg-gradient-to-r from-blue-600 to-indigo-600 text-white font-semibold text-sm shadow-lg shadow-blue-500/25 active:scale-[0.98] transition-transform flex items-center justify-center gap-2"
      >
        <QrCode size={20} /> Scan / Pay Canteen QR
      </button>

      {/* Food transactions */}
      <div>
        <div className="flex items-center gap-2 mb-3">
          <Calendar size={16} className="text-slate-700" />
          <h3 className="text-base font-bold text-slate-900">Food Transactions</h3>
        </div>
        {foodTransactions.length === 0 ? (
          <p className="text-sm text-slate-400 text-center py-4">No food transactions yet.</p>
        ) : (
          <div className="space-y-2.5">
            {foodTransactions.slice(0, 10).map((tx) => (
              <div key={tx.id} className="bg-white rounded-2xl p-3.5 border border-slate-100 shadow-sm flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-rose-50 flex items-center justify-center flex-shrink-0">
                  <Utensils size={18} className="text-rose-600" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold text-slate-800">{tx.title}</p>
                  <p className="text-[11px] text-slate-400 mt-0.5">{tx.date}</p>
                </div>
                <span className="text-sm font-bold text-rose-600">−₹{tx.amount}</span>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Payment modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/40 backdrop-blur-sm animate-fade-in">
          <div className="w-full max-w-md bg-white rounded-t-3xl sm:rounded-3xl p-5 space-y-4 animate-slide-up">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-slate-900">Pay Canteen QR</h3>
              <button
                onClick={() => setShowModal(false)}
                className="w-8 h-8 rounded-full flex items-center justify-center text-slate-400 hover:bg-slate-100 active:scale-90 transition-all"
              >
                <X size={18} />
              </button>
            </div>

            <div className="flex items-center justify-center py-3">
              <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-blue-100 to-indigo-100 flex items-center justify-center">
                <QrCode size={40} className="text-blue-600" />
              </div>
            </div>

            {/* Item selection */}
            <div>
              <label className="text-xs font-semibold text-slate-500 mb-1.5 block">Select item</label>
              <div className="grid grid-cols-3 gap-2">
                {FOOD_ITEMS.map((item) => (
                  <button
                    key={item.name}
                    onClick={() => {
                      setSelectedItem(item);
                      setAmount(item.defaultAmount);
                    }}
                    className={`p-2.5 rounded-xl border text-xs font-medium transition-all ${
                      selectedItem.name === item.name
                        ? 'border-blue-500 bg-blue-50 text-blue-700'
                        : 'border-slate-100 bg-slate-50 text-slate-500'
                    }`}
                  >
                    {item.name}
                  </button>
                ))}
              </div>
            </div>

            {/* Amount */}
            <div>
              <label className="text-xs font-semibold text-slate-500 mb-1.5 block">Amount (₹)</label>
              <input
                type="number"
                value={amount}
                onChange={(e) => setAmount(Math.max(0, parseInt(e.target.value) || 0))}
                className="w-full bg-slate-50 rounded-xl px-4 py-3 text-sm font-semibold text-slate-800 outline-none border border-slate-100 focus:border-blue-300 focus:bg-white transition-colors"
              />
            </div>

            {amount > data.walletBalance && (
              <p className="text-xs text-rose-600 font-medium">Insufficient wallet balance.</p>
            )}

            <button
              onClick={handlePay}
              disabled={amount <= 0 || amount > data.walletBalance}
              className={`w-full py-3.5 rounded-2xl font-semibold text-sm flex items-center justify-center gap-2 transition-all ${
                amount > 0 && amount <= data.walletBalance
                  ? 'bg-blue-600 text-white shadow-lg shadow-blue-500/25 active:scale-[0.98]'
                  : 'bg-slate-200 text-slate-400'
              }`}
            >
              <Check size={16} /> Confirm Payment ₹{amount}
            </button>

            <p className="text-center text-[10px] text-slate-400">Demo payment — no real money transferred.</p>
          </div>
        </div>
      )}

      {/* Pay toast */}
      {payToast && (
        <div className="fixed bottom-28 left-1/2 -translate-x-1/2 z-50 animate-slide-up">
          <div className="bg-slate-900 text-white text-sm font-medium px-5 py-3 rounded-2xl shadow-xl flex items-center gap-2">
            <Check size={16} className="text-emerald-400" /> ₹{paidAmount} paid to {selectedItem.name}
          </div>
        </div>
      )}
    </div>
  );
}
