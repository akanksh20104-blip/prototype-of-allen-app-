import { CheckCircle2, XCircle, TrendingUp, Award, Target } from 'lucide-react';
import type { StudentProfile } from '@/types';

interface ProgressScreenProps {
  data: StudentProfile;
}

export default function ProgressScreen({ data }: ProgressScreenProps) {
  const history = [...data.quizHistory].reverse();
  const totalQuizzes = data.quizHistory.length;
  const totalCorrect = data.quizHistory.reduce((s, q) => s + q.correct, 0);
  const totalWrong = data.quizHistory.reduce((s, q) => s + q.wrong, 0);
  const avgScore = totalQuizzes > 0 ? Math.round(data.quizHistory.reduce((s, q) => s + q.score, 0) / totalQuizzes) : 0;

  const summary = [
    { label: 'Total Quizzes', value: totalQuizzes, color: 'text-blue-600', bg: 'bg-blue-50', icon: Target },
    { label: 'Average Score', value: `${avgScore}%`, color: 'text-emerald-600', bg: 'bg-emerald-50', icon: TrendingUp },
    { label: 'Total Correct', value: totalCorrect, color: 'text-green-600', bg: 'bg-green-50', icon: CheckCircle2 },
    { label: 'Total Wrong', value: totalWrong, color: 'text-rose-600', bg: 'bg-rose-50', icon: XCircle },
  ];

  return (
    <div className="px-5 py-4 space-y-5 animate-fade-in">
      <h2 className="text-lg font-bold text-slate-900">Quiz Progress</h2>

      {/* Summary */}
      <div className="grid grid-cols-2 gap-3">
        {summary.map((s) => {
          const Icon = s.icon;
          return (
            <div key={s.label} className="bg-white rounded-2xl p-3.5 border border-slate-100 shadow-sm">
              <div className={`w-8 h-8 rounded-lg ${s.bg} flex items-center justify-center mb-2`}>
                <Icon size={16} className={s.color} />
              </div>
              <p className="text-xl font-bold text-slate-900 leading-none">{s.value}</p>
              <p className="text-[11px] text-slate-400 mt-1">{s.label}</p>
            </div>
          );
        })}
      </div>

      {/* Quiz history */}
      <div>
        <h3 className="text-base font-bold text-slate-900 mb-3">Quiz History</h3>
        {history.length === 0 ? (
          <p className="text-sm text-slate-400 text-center py-8">No quizzes attempted yet.</p>
        ) : (
          <div className="space-y-3">
            {history.map((quiz) => (
              <div key={quiz.id} className="bg-white rounded-2xl p-4 border border-slate-100 shadow-sm">
                <div className="flex items-start justify-between mb-2">
                  <div>
                    <p className="text-sm font-bold text-slate-800">{quiz.chapterName}</p>
                    <p className="text-[11px] text-slate-400 mt-0.5">{quiz.date}</p>
                  </div>
                  <span className={`text-sm font-bold ${quiz.score >= 80 ? 'text-emerald-600' : quiz.score >= 50 ? 'text-amber-600' : 'text-rose-600'}`}>
                    {quiz.score}%
                  </span>
                </div>
                <div className="flex items-center gap-4 mt-2.5">
                  <span className="flex items-center gap-1 text-xs">
                    <span className="text-slate-400">Questions:</span>
                    <span className="font-semibold text-slate-700">{quiz.totalQuestions}</span>
                  </span>
                  <span className="flex items-center gap-1 text-xs">
                    <CheckCircle2 size={14} className="text-emerald-500" />
                    <span className="font-semibold text-emerald-600">{quiz.correct}</span>
                  </span>
                  <span className="flex items-center gap-1 text-xs">
                    <XCircle size={14} className="text-rose-500" />
                    <span className="font-semibold text-rose-600">{quiz.wrong}</span>
                  </span>
                </div>
                <div className="flex items-center justify-between mt-3 pt-3 border-t border-slate-50">
                  <span className="flex items-center gap-1 text-[11px] text-slate-400">
                    {quiz.source === 'offline' ? 'Offline question bank' : 'Google-assisted quiz'}
                  </span>
                  <span className="flex items-center gap-1 text-xs font-bold text-amber-600">
                    <Award size={13} /> +{quiz.xpEarned} XP
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
