import { useState } from 'react';
import {
  Wallet,
  TrendingUp,
  ArrowDownLeft,
  ArrowUpRight,
  Leaf,
  Lightbulb,
  Utensils,
  BookOpen,
  Bus,
  Gift,
  ChevronRight,
  Sparkles,
  TreePine,
} from 'lucide-react';

type SubTab = 'balance' | 'suggestions' | 'statements';

const SUB_TABS: { id: SubTab; label: string }[] = [
  { id: 'balance', label: 'Balance' },
  { id: 'suggestions', label: 'Suggestions' },
  { id: 'statements', label: 'Statements' },
];

interface Transaction {
  id: number;
  title: string;
  date: string;
  amount: string;
  type: 'credit' | 'debit';
  icon: typeof BookOpen;
  color: string;
  bg: string;
}

const TRANSACTIONS: Transaction[] = [
  { id: 1, title: 'Canteen — Lunch combo', date: 'Today, 12:40 PM', amount: '45 AC', type: 'debit', icon: Utensils, color: 'text-emerald-600', bg: 'bg-emerald-50' },
  { id: 2, title: 'Library book deposit', date: 'Today, 9:15 AM', amount: '20 AC', type: 'debit', icon: BookOpen, color: 'text-blue-600', bg: 'bg-blue-50' },
  { id: 3, title: 'Campus bus pass top-up', date: 'Yesterday, 5:30 PM', amount: '100 AC', type: 'debit', icon: Bus, color: 'text-amber-600', bg: 'bg-amber-50' },
  { id: 4, title: 'Scholarship reward', date: 'Sep 25, 11:00 AM', amount: '500 AC', type: 'credit', icon: Gift, color: 'text-rose-600', bg: 'bg-rose-50' },
  { id: 5, title: 'Workshop registration', date: 'Sep 24, 2:00 PM', amount: '75 AC', type: 'debit', icon: BookOpen, color: 'text-violet-600', bg: 'bg-violet-50' },
  { id: 6, title: 'Canteen — Snacks', date: 'Sep 23, 4:15 PM', amount: '30 AC', type: 'debit', icon: Utensils, color: 'text-emerald-600', bg: 'bg-emerald-50' },
];

const SUGGESTIONS = [
  { id: 1, title: 'Spend on canteen meals', desc: 'Use ALLEN Currency for healthy canteen food instead of cash — you save 5% per meal.', icon: Utensils, color: 'text-emerald-600', bg: 'bg-emerald-50' },
  { id: 2, title: 'Reserve library books early', desc: 'Book deposits cost 20 AC. Return on time to get it back.', icon: BookOpen, color: 'text-blue-600', bg: 'bg-blue-50' },
  { id: 3, title: 'Top up bus pass monthly', desc: 'A 100 AC bus pass saves you ₹400 in transport every month.', icon: Bus, color: 'text-amber-600', bg: 'bg-amber-50' },
  { id: 4, title: 'Earn through workshops', desc: 'Selected campus workshops reward 50–200 AC for participation.', icon: Gift, color: 'text-rose-600', bg: 'bg-rose-50' },
  { id: 5, title: 'Plant saplings — earn back', desc: 'Payments above ₹1000 trigger 10 saplings planted in your name on campus.', icon: TreePine, color: 'text-green-600', bg: 'bg-green-50' },
];

const STATEMENTS = [
  { id: 1, title: '10 saplings planted in campus', desc: 'For your payment of ₹1,200 on Sep 25, 2026', date: 'Sep 25, 2026', amount: '₹1,200', trees: 10, status: 'Completed' },
  { id: 2, title: '10 saplings planted in campus', desc: 'For your payment of ₹1,500 on Sep 18, 2026', date: 'Sep 18, 2026', amount: '₹1,500', trees: 10, status: 'Completed' },
  { id: 3, title: '10 saplings planted in campus', desc: 'For your payment of ₹2,000 on Sep 10, 2026', date: 'Sep 10, 2026', amount: '₹2,000', trees: 10, status: 'Completed' },
  { id: 4, title: '10 saplings planted in campus', desc: 'For your payment of ₹1,100 on Sep 02, 2026', date: 'Sep 02, 2026', amount: '₹1,100', trees: 10, status: 'Completed' },
];

export default function ExploreScreen() {
  const [subTab, setSubTab] = useState<SubTab>('balance');

  return (
    <div className="px-5 py-4 space-y-5 animate-fade-in">
      {/* Balance hero */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-blue-700 via-blue-600 to-indigo-600 p-6 shadow-xl shadow-blue-500/20">
        <div className="absolute -top-10 -right-10 w-40 h-40 rounded-full bg-white/10" />
        <div className="absolute -bottom-12 -left-8 w-28 h-28 rounded-full bg-white/5" />
        <div className="relative">
          <div className="flex items-center gap-2">
            <Wallet size={18} className="text-white" />
            <span className="text-white/80 text-xs font-semibold uppercase tracking-wide">ALLEN Currency Balance</span>
          </div>
          <div className="flex items-end gap-2 mt-3">
            <span className="text-white text-4xl font-bold leading-none">1,247</span>
            <span className="text-blue-200 text-lg font-semibold mb-1">AC</span>
          </div>
          <div className="flex items-center gap-1.5 mt-2">
            <TrendingUp size={14} className="text-emerald-300" />
            <span className="text-emerald-300 text-xs font-medium">+500 AC this month</span>
          </div>
          <div className="flex gap-3 mt-5">
            <div className="flex-1 bg-white/15 rounded-xl p-2.5 backdrop-blur-sm">
              <div className="flex items-center gap-1.5">
                <ArrowDownLeft size={14} className="text-emerald-300" />
                <span className="text-[10px] text-blue-100">Earned</span>
              </div>
              <p className="text-white font-bold text-sm mt-1">750 AC</p>
            </div>
            <div className="flex-1 bg-white/15 rounded-xl p-2.5 backdrop-blur-sm">
              <div className="flex items-center gap-1.5">
                <ArrowUpRight size={14} className="text-rose-300" />
                <span className="text-[10px] text-blue-100">Spent</span>
              </div>
              <p className="text-white font-bold text-sm mt-1">253 AC</p>
            </div>
          </div>
        </div>
      </div>

      {/* Secondary tabs */}
      <div className="flex gap-1 bg-slate-100 rounded-2xl p-1">
        {SUB_TABS.map((tab) => {
          const isActive = subTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setSubTab(tab.id)}
              className={`flex-1 py-2.5 rounded-xl text-sm font-semibold transition-all ${
                isActive ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500'
              }`}
            >
              {tab.label}
            </button>
          );
        })}
      </div>

      {/* Balance tab — transactions */}
      {subTab === 'balance' && (
        <div className="space-y-2.5 animate-fade-in">
          <h3 className="text-base font-bold text-slate-900 mb-1">Recent transactions</h3>
          {TRANSACTIONS.map((tx) => {
            const Icon = tx.icon;
            return (
              <div key={tx.id} className="bg-white rounded-2xl p-3.5 border border-slate-100 shadow-sm flex items-center gap-3">
                <div className={`w-10 h-10 rounded-xl ${tx.bg} flex items-center justify-center flex-shrink-0`}>
                  <Icon size={18} className={tx.color} />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold text-slate-800 truncate">{tx.title}</p>
                  <p className="text-[11px] text-slate-400 mt-0.5">{tx.date}</p>
                </div>
                <span className={`text-sm font-bold ${tx.type === 'credit' ? 'text-emerald-600' : 'text-slate-700'}`}>
                  {tx.type === 'credit' ? '+' : '−'}{tx.amount}
                </span>
              </div>
            );
          })}
        </div>
      )}

      {/* Suggestions tab */}
      {subTab === 'suggestions' && (
        <div className="space-y-3 animate-fade-in">
          <div className="flex items-start gap-2.5 bg-amber-50 rounded-2xl p-3.5 border border-amber-100">
            <Lightbulb size={18} className="text-amber-600 flex-shrink-0 mt-0.5" />
            <p className="text-xs text-amber-700 leading-relaxed">
              Smart ways to use your ALLEN Currency. Every ₹1,000+ payment plants 10 saplings on campus!
            </p>
          </div>
          {SUGGESTIONS.map((s) => {
            const Icon = s.icon;
            return (
              <div key={s.id} className="bg-white rounded-2xl p-4 border border-slate-100 shadow-sm flex items-start gap-3 active:scale-[0.98] transition-transform cursor-pointer">
                <div className={`w-10 h-10 rounded-xl ${s.bg} flex items-center justify-center flex-shrink-0`}>
                  <Icon size={18} className={s.color} />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold text-slate-800">{s.title}</p>
                  <p className="text-[11px] text-slate-400 mt-0.5 leading-relaxed">{s.desc}</p>
                </div>
                <ChevronRight size={18} className="text-slate-300 flex-shrink-0 mt-1" />
              </div>
            );
          })}
          {/* Sapling highlight card */}
          <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-green-600 to-emerald-600 p-4 shadow-lg shadow-green-500/20">
            <div className="absolute -top-6 -right-6 w-24 h-24 rounded-full bg-white/10" />
            <div className="relative flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-white/20 flex items-center justify-center flex-shrink-0">
                <TreePine size={24} className="text-white" />
              </div>
              <div>
                <p className="text-white font-bold text-sm">40 saplings planted in your name</p>
                <p className="text-green-100 text-[11px] mt-0.5">Across 4 payments above ₹1,000 this month</p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Statements tab — sapling statements */}
      {subTab === 'statements' && (
        <div className="space-y-3 animate-fade-in">
          <div className="flex items-center gap-2 mb-1">
            <Leaf size={16} className="text-green-600" />
            <h3 className="text-base font-bold text-slate-900">Sapling plantation statements</h3>
          </div>
          <p className="text-xs text-slate-400 -mt-2 mb-1">
            For every payment above ₹1,000, 10 saplings are planted on campus in your name.
          </p>
          {STATEMENTS.map((stmt) => (
            <div key={stmt.id} className="bg-white rounded-2xl p-4 border border-slate-100 shadow-sm">
              <div className="flex items-start gap-3">
                <div className="w-11 h-11 rounded-xl bg-green-50 flex items-center justify-center flex-shrink-0">
                  <TreePine size={20} className="text-green-600" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold text-slate-800">{stmt.title}</p>
                  <p className="text-[11px] text-slate-400 mt-0.5">{stmt.desc}</p>
                  <div className="flex items-center gap-3 mt-2">
                    <span className="text-xs font-bold text-slate-700">{stmt.amount}</span>
                    <span className="flex items-center gap-1 text-[11px] text-green-600 bg-green-50 px-2 py-0.5 rounded-full font-semibold">
                      <Sparkles size={10} /> {stmt.trees} trees
                    </span>
                    <span className="text-[11px] text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-full font-semibold">
                      {stmt.status}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          ))}
          <div className="flex items-center justify-between bg-slate-900 rounded-2xl p-4">
            <div>
              <p className="text-slate-300 text-xs">Total saplings planted</p>
              <p className="text-white text-2xl font-bold mt-0.5">40 trees</p>
            </div>
            <div className="text-right">
              <p className="text-slate-300 text-xs">Total contributed</p>
              <p className="text-white text-lg font-bold mt-0.5">₹5,800</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
