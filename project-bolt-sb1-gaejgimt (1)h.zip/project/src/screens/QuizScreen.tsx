import { useState } from 'react';
import { BookOpen, ChevronRight, CheckCircle2, XCircle, Award, Sparkles, RefreshCw } from 'lucide-react';
import type { StudentProfile, QuizAttempt } from '@/types';
import { CHAPTERS } from '@/data/chapters';
import { addQuizAttempt } from '@/hooks/useStudentData';

interface QuizScreenProps {
  data: StudentProfile;
  setData: (d: StudentProfile) => void;
  presetChapterId?: string | null;
}

type Phase = 'select' | 'quiz' | 'result';

export default function QuizScreen({ data, setData, presetChapterId }: QuizScreenProps) {
  const [phase, setPhase] = useState<Phase>('select');
  const [selectedChapter, setSelectedChapter] = useState<string | null>(presetChapterId ?? null);
  const [currentQ, setCurrentQ] = useState(0);
  const [answers, setAnswers] = useState<number[]>([]);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [showResult, setShowResult] = useState(false);

  const chapter = CHAPTERS.find((c) => c.id === selectedChapter);
  const questions = chapter?.questions ?? [];
  const totalQuestions = questions.length;

  const handleStart = () => {
    if (!selectedChapter) return;
    setPhase('quiz');
    setCurrentQ(0);
    setAnswers([]);
    setSelectedAnswer(null);
    setShowResult(false);
  };

  const handleAnswer = (idx: number) => {
    if (showResult) return;
    setSelectedAnswer(idx);
    setShowResult(true);
  };

  const handleNext = () => {
    const newAnswers = [...answers, selectedAnswer!];
    setAnswers(newAnswers);
    setSelectedAnswer(null);
    setShowResult(false);
    if (currentQ + 1 < totalQuestions) {
      setCurrentQ(currentQ + 1);
    } else {
      finishQuiz(newAnswers);
    }
  };

  const finishQuiz = (allAnswers: number[]) => {
    if (!chapter) return;
    let correct = 0;
    questions.forEach((q, i) => {
      if (allAnswers[i] === q.correctIndex) correct++;
    });
    const wrong = totalQuestions - correct;
    const score = Math.round((correct / totalQuestions) * 100);
    let xpEarned = correct * 20;
    xpEarned += 20; // completion bonus
    if (correct === totalQuestions) xpEarned += 50; // perfect bonus

    const attempt: QuizAttempt = {
      id: `quiz-${Date.now()}`,
      chapterId: chapter.id,
      chapterName: chapter.name,
      date: new Date().toISOString().split('T')[0],
      totalQuestions,
      correct,
      wrong,
      score,
      xpEarned,
      source: 'offline',
    };
    setData(addQuizAttempt(data, attempt));
    setPhase('result');
  };

  const handleRestart = () => {
    setPhase('select');
    setSelectedChapter(null);
    setAnswers([]);
    setCurrentQ(0);
  };

  // Select phase
  if (phase === 'select') {
    return (
      <div className="px-5 py-4 space-y-4 animate-fade-in">
        <h2 className="text-lg font-bold text-slate-900">Choose a chapter</h2>
        <div className="space-y-2.5">
          {CHAPTERS.map((c) => {
            const isSelected = selectedChapter === c.id;
            const isScanned = data.scannedChapters.includes(c.id);
            return (
              <button
                key={c.id}
                onClick={() => setSelectedChapter(c.id)}
                className={`w-full flex items-center gap-3 p-3.5 rounded-2xl border transition-all active:scale-[0.98] text-left ${
                  isSelected
                    ? 'border-emerald-500 bg-emerald-50 ring-1 ring-emerald-200'
                    : 'border-slate-100 bg-white shadow-sm'
                }`}
              >
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 ${
                  isSelected ? 'bg-emerald-100' : 'bg-slate-100'
                }`}>
                  <BookOpen size={18} className={isSelected ? 'text-emerald-600' : 'text-slate-500'} />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold text-slate-800">{c.name}</p>
                  <p className="text-[11px] text-slate-400">{c.questions.length} questions</p>
                </div>
                {isScanned && (
                  <span className="text-[10px] font-semibold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-full">
                    Scanned
                  </span>
                )}
                {isSelected && <CheckCircle2 size={18} className="text-emerald-600 flex-shrink-0" />}
              </button>
            );
          })}
        </div>

        <div className="flex items-center gap-1.5 text-[11px] text-slate-400">
          <Sparkles size={12} /> Offline question bank
        </div>

        <button
          onClick={handleStart}
          disabled={!selectedChapter}
          className={`w-full py-3.5 rounded-2xl font-semibold text-sm transition-all ${
            selectedChapter
              ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-500/25 active:scale-[0.98]'
              : 'bg-slate-200 text-slate-400'
          }`}
        >
          Generate Quiz
        </button>
      </div>
    );
  }

  // Quiz phase
  if (phase === 'quiz' && chapter) {
    const q = questions[currentQ];
    return (
      <div className="px-5 py-4 space-y-5 animate-fade-in">
        {/* Progress bar */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold text-slate-500">
              Question {currentQ + 1} of {totalQuestions}
            </span>
            <span className="text-[11px] text-slate-400">{chapter.name}</span>
          </div>
          <div className="h-1.5 rounded-full bg-slate-100 overflow-hidden">
            <div
              className="h-full rounded-full bg-emerald-500 transition-all"
              style={{ width: `${((currentQ) / totalQuestions) * 100}%` }}
            />
          </div>
        </div>

        {/* Question */}
        <div className="bg-white rounded-2xl p-5 border border-slate-100 shadow-sm">
          <p className="text-base font-semibold text-slate-800 leading-snug">{q.question}</p>
        </div>

        {/* Options */}
        <div className="space-y-2.5">
          {q.options.map((opt, i) => {
            const isCorrect = i === q.correctIndex;
            const isSelected = selectedAnswer === i;
            let style = 'border-slate-100 bg-white text-slate-700';
            if (showResult && isCorrect) {
              style = 'border-emerald-500 bg-emerald-50 text-emerald-700';
            } else if (showResult && isSelected && !isCorrect) {
              style = 'border-rose-500 bg-rose-50 text-rose-700';
            } else if (!showResult) {
              style = 'border-slate-100 bg-white text-slate-700 active:scale-[0.98]';
            }
            return (
              <button
                key={i}
                onClick={() => handleAnswer(i)}
                disabled={showResult}
                className={`w-full flex items-center gap-3 p-3.5 rounded-2xl border transition-all text-left ${style}`}
              >
                <span className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0 ${
                  showResult && isCorrect ? 'bg-emerald-500 text-white' :
                  showResult && isSelected && !isCorrect ? 'bg-rose-500 text-white' :
                  'bg-slate-100 text-slate-500'
                }`}>
                  {String.fromCharCode(65 + i)}
                </span>
                <span className="text-sm font-medium flex-1">{opt}</span>
                {showResult && isCorrect && <CheckCircle2 size={18} className="text-emerald-600" />}
                {showResult && isSelected && !isCorrect && <XCircle size={18} className="text-rose-600" />}
              </button>
            );
          })}
        </div>

        {/* Next button */}
        {showResult && (
          <button
            onClick={handleNext}
            className="w-full py-3.5 rounded-2xl bg-emerald-600 text-white font-semibold text-sm shadow-lg shadow-emerald-500/25 active:scale-[0.98] transition-transform flex items-center justify-center gap-2"
          >
            {currentQ + 1 < totalQuestions ? 'Next Question' : 'See Results'}
            <ChevronRight size={16} />
          </button>
        )}
      </div>
    );
  }

  // Result phase
  if (phase === 'result' && chapter) {
    const correct = questions.filter((q, i) => answers[i] === q.correctIndex).length;
    const wrong = totalQuestions - correct;
    const score = Math.round((correct / totalQuestions) * 100);
    let xpEarned = correct * 20 + 20;
    if (correct === totalQuestions) xpEarned += 50;

    const badge = score === 100 ? '🎉 Perfect score!' : score >= 80 ? '🎉 Great work!' : score >= 50 ? '👍 Good effort!' : '📚 Keep practicing!';

    return (
      <div className="px-5 py-4 space-y-5 animate-fade-in">
        <div className="text-center py-6">
          <div className="w-20 h-20 rounded-full bg-gradient-to-br from-emerald-400 to-teal-500 flex items-center justify-center mx-auto mb-4 shadow-lg shadow-emerald-500/20">
            <Award size={36} className="text-white" />
          </div>
          <p className="text-lg font-bold text-slate-900">{badge}</p>
          <p className="text-sm text-slate-500 mt-1">{chapter.name}</p>
        </div>

        <div className="bg-white rounded-2xl p-5 border border-slate-100 shadow-sm space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-sm text-slate-500">Score</span>
            <span className="text-lg font-bold text-slate-900">{correct} / {totalQuestions} correct</span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-sm text-slate-500">Correct answers</span>
            <span className="flex items-center gap-1 text-sm font-semibold text-emerald-600">
              <CheckCircle2 size={15} /> {correct}
            </span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-sm text-slate-500">Wrong answers</span>
            <span className="flex items-center gap-1 text-sm font-semibold text-rose-600">
              <XCircle size={15} /> {wrong}
            </span>
          </div>
          <div className="flex items-center justify-between pt-3 border-t border-slate-50">
            <span className="text-sm text-slate-500">XP earned</span>
            <span className="text-lg font-bold text-amber-600">+{xpEarned} XP</span>
          </div>
        </div>

        <div className="flex items-center gap-1.5 text-[11px] text-slate-400 justify-center">
          <Sparkles size={12} /> Offline question bank
        </div>

        <button
          onClick={handleRestart}
          className="w-full py-3.5 rounded-2xl bg-emerald-600 text-white font-semibold text-sm shadow-lg shadow-emerald-500/25 active:scale-[0.98] transition-transform flex items-center justify-center gap-2"
        >
          <RefreshCw size={16} /> Take Another Quiz
        </button>
      </div>
    );
  }

  return null;
}
