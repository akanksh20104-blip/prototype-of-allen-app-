import { useState } from 'react';
import {
  Wind,
  Moon,
  Leaf,
  Brain,
  Code,
  Languages,
  Music,
  Camera,
  Heart,
  TrendingUp,
  Flame,
  Check,
  Clock,
} from 'lucide-react';

type SubTab = 'relaxation' | 'skills';

interface Activity {
  id: number;
  title: string;
  desc: string;
  duration: string;
  level: string;
  icon: typeof Wind;
  color: string;
  bg: string;
}

const SUB_TABS: { id: SubTab; label: string; icon: typeof Wind }[] = [
  { id: 'relaxation', label: 'Relaxation', icon: Wind },
  { id: 'skills', label: 'New Skills', icon: Brain },
];

const ACTIVITIES: Record<SubTab, Activity[]> = {
  relaxation: [
    { id: 1, title: 'Box Breathing', desc: '4-4-4-4 technique to calm exam anxiety', duration: '5 min', level: 'Beginner', icon: Wind, color: 'text-sky-600', bg: 'bg-sky-50' },
    { id: 2, title: 'Sleep Meditation', desc: 'Guided audio for deep, restful sleep', duration: '15 min', level: 'Beginner', icon: Moon, color: 'text-indigo-600', bg: 'bg-indigo-50' },
    { id: 3, title: 'Body Scan Relaxation', desc: 'Release tension from head to toe', duration: '10 min', level: 'Beginner', icon: Leaf, color: 'text-emerald-600', bg: 'bg-emerald-50' },
    { id: 4, title: 'Mindful Walking', desc: 'Slow, grounding walk between study blocks', duration: '8 min', level: 'All', icon: Wind, color: 'text-teal-600', bg: 'bg-teal-50' },
  ],
  skills: [
    { id: 1, title: 'Coding Basics', desc: 'Python & DSA fundamentals for beginners', duration: '4 weeks', level: 'Beginner', icon: Code, color: 'text-blue-600', bg: 'bg-blue-50' },
    { id: 2, title: 'Spoken English', desc: 'Confidence in conversation and interviews', duration: '6 weeks', level: 'Intermediate', icon: Languages, color: 'text-rose-600', bg: 'bg-rose-50' },
    { id: 3, title: 'Music Production', desc: 'Make your first track with free tools', duration: '8 weeks', level: 'Beginner', icon: Music, color: 'text-violet-600', bg: 'bg-violet-50' },
    { id: 4, title: 'Photography', desc: 'Composition, lighting & phone camera tips', duration: '3 weeks', level: 'Beginner', icon: Camera, color: 'text-amber-600', bg: 'bg-amber-50' },
  ],
};

const HEALTH_STATS = [
  { label: 'Sleep', value: '7.2', unit: 'hrs avg', color: 'text-indigo-600', bg: 'bg-indigo-50', icon: Moon },
  { label: 'Streak', value: '14', unit: 'days', color: 'text-emerald-600', bg: 'bg-emerald-50', icon: Flame },
  { label: 'Sessions', value: '32', unit: 'this month', color: 'text-rose-600', bg: 'bg-rose-50', icon: Heart },
];

const WEEKLY = [
  { day: 'M', value: 60 },
  { day: 'T', value: 40 },
  { day: 'W', value: 80 },
  { day: 'T', value: 50 },
  { day: 'F', value: 70 },
  { day: 'S', value: 90 },
  { day: 'S', value: 30 },
];

export default function HealthScreen() {
  const [subTab, setSubTab] = useState<SubTab>('relaxation');
  const [started, setStarted] = useState<number | null>(null);

  const activities = ACTIVITIES[subTab];

  const handleStart = (id: number) => {
    setStarted(id);
    setTimeout(() => setStarted(null), 2500);
  };

  return (
    <div className="px-5 py-4 space-y-5 animate-fade-in">
      {/* Health overview card */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-rose-500 via-rose-500 to-pink-600 p-5 shadow-xl shadow-rose-500/20">
        <div className="absolute -top-8 -right-8 w-32 h-32 rounded-full bg-white/10" />
        <div className="relative">
          <div className="flex items-center gap-2">
            <Heart size={18} className="text-white" />
            <h2 className="text-white text-lg font-bold">Wellness overview</h2>
          </div>
          <p className="mt-1 text-rose-100 text-sm">You're doing better than 68% of students this week.</p>
          {/* Weekly bar chart */}
          <div className="flex items-end justify-between gap-1.5 mt-4 h-16">
            {WEEKLY.map((w, i) => (
              <div key={i} className="flex-1 flex flex-col items-center gap-1">
                <div className="w-full bg-white/20 rounded-lg overflow-hidden flex items-end" style={{ height: '48px' }}>
                  <div
                    className="w-full bg-white rounded-lg transition-all"
                    style={{ height: `${w.value}%` }}
                  />
                </div>
                <span className="text-[10px] text-rose-100 font-medium">{w.day}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Health stats */}
      <div className="grid grid-cols-3 gap-3">
        {HEALTH_STATS.map((s) => {
          const Icon = s.icon;
          return (
            <div key={s.label} className="bg-white rounded-2xl p-3.5 border border-slate-100 shadow-sm">
              <div className={`w-8 h-8 rounded-lg ${s.bg} flex items-center justify-center mb-2`}>
                <Icon size={16} className={s.color} />
              </div>
              <p className="text-lg font-bold text-slate-900 leading-none">{s.value}</p>
              <p className="text-[11px] text-slate-400 mt-0.5">{s.unit} · {s.label}</p>
            </div>
          );
        })}
      </div>

      {/* Secondary tabs */}
      <div className="flex gap-2 bg-slate-100 rounded-2xl p-1">
        {SUB_TABS.map((tab) => {
          const Icon = tab.icon;
          const isActive = subTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setSubTab(tab.id)}
              className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl text-sm font-semibold transition-all ${
                isActive ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500'
              }`}
            >
              <Icon size={16} />
              {tab.label}
            </button>
          );
        })}
      </div>

      {/* Activity list */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-base font-bold text-slate-900">
            {subTab === 'relaxation' ? 'Relax & recharge' : 'Learn something new'}
          </h3>
          <span className="text-xs text-slate-400">{activities.length} activities</span>
        </div>
        <div className="space-y-3">
          {activities.map((a) => {
            const Icon = a.icon;
            const isStarted = started === a.id;
            return (
              <div key={a.id} className="bg-white rounded-2xl border border-slate-100 shadow-sm p-3.5">
                <div className="flex items-start gap-3">
                  <div className={`w-11 h-11 rounded-xl ${a.bg} flex items-center justify-center flex-shrink-0`}>
                    <Icon size={20} className={a.color} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-semibold text-slate-800">{a.title}</p>
                    <p className="text-[11px] text-slate-400 mt-0.5 leading-snug">{a.desc}</p>
                    <div className="flex items-center gap-3 mt-2">
                      <span className="flex items-center gap-1 text-[11px] text-slate-500">
                        <Clock size={11} /> {a.duration}
                      </span>
                      <span className="text-[11px] text-slate-500">{a.level}</span>
                    </div>
                  </div>
                </div>
                <button
                  onClick={() => handleStart(a.id)}
                  className={`w-full mt-3 py-2.5 rounded-xl text-sm font-semibold flex items-center justify-center gap-1.5 transition-all active:scale-[0.98] ${
                    isStarted
                      ? 'bg-emerald-500 text-white'
                      : subTab === 'relaxation'
                      ? 'bg-sky-50 text-sky-700'
                      : 'bg-blue-50 text-blue-700'
                  }`}
                >
                  {isStarted ? (
                    <>
                      <Check size={15} /> Started!
                    </>
                  ) : subTab === 'relaxation' ? (
                    'Begin session'
                  ) : (
                    'Start learning'
                  )}
                </button>
              </div>
            );
          })}
        </div>
      </div>

      {/* Tip card */}
      <div className="flex items-start gap-2.5 bg-emerald-50 rounded-2xl p-3.5 border border-emerald-100">
        <TrendingUp size={18} className="text-emerald-600 flex-shrink-0 mt-0.5" />
        <p className="text-xs text-emerald-700 leading-relaxed">
          Even 5 minutes of breathing between study sessions can improve retention by up to 20%.
        </p>
      </div>
    </div>
  );
}
