import { useState } from 'react';
import {
  User,
  Languages,
  Hash,
  Mail,
  Phone,
  MapPin,
  GraduationCap,
  Calendar,
  Edit3,
  Check,
  ChevronRight,
  Shield,
  Bell,
  HelpCircle,
} from 'lucide-react';

type SubTab = 'details' | 'preferences';

const SUB_TABS: { id: SubTab; label: string }[] = [
  { id: 'details', label: 'Profile Details' },
  { id: 'preferences', label: 'Preferences' },
];

interface ProfileField {
  id: string;
  label: string;
  value: string;
  icon: typeof User;
  editable: boolean;
}

const PROFILE_DETAILS: ProfileField[] = [
  { id: 'name', label: 'Full Name', value: 'Aarav Sharma', icon: User, editable: true },
  { id: 'form', label: 'Form Number', value: 'ALN-2026-04891', icon: Hash, editable: false },
  { id: 'email', label: 'Email', value: 'aarav.sharma@allen.in', icon: Mail, editable: true },
  { id: 'phone', label: 'Phone', value: '+91 98765 43210', icon: Phone, editable: true },
  { id: 'language', label: 'Language', value: 'English', icon: Languages, editable: true },
  { id: 'course', label: 'Course', value: 'JEE Advanced — 2 Year', icon: GraduationCap, editable: true },
  { id: 'center', label: 'Center', value: 'Kota, Rajasthan', icon: MapPin, editable: false },
  { id: 'dob', label: 'Date of Birth', value: '14 Aug 2008', icon: Calendar, editable: true },
];

const LANGUAGES = ['English', 'Hindi', 'Gujarati', 'Marathi', 'Tamil', 'Telugu', 'Bengali'];

const SETTINGS = [
  { id: 'notifications', label: 'Notifications', desc: 'Exam alerts & reminders', icon: Bell },
  { id: 'privacy', label: 'Privacy & Security', desc: 'Account access & data', icon: Shield },
  { id: 'help', label: 'Help & Support', desc: 'FAQs, contact us', icon: HelpCircle },
];

interface ProfileScreenProps {
  language: string;
  onLanguageChange: (lang: string) => void;
  course: string;
  onCourseChange: (course: string) => void;
}

const COURSES = [
  'JEE Advanced — 2 Year',
  'JEE Main — 1 Year',
  'NEET — 2 Year',
  'NEET — 1 Year',
  'Foundation 8th',
  'Foundation 9th',
  'Foundation 10th',
  'Class 11 Science',
  'Class 12 Science',
];

export default function ProfileScreen({ language, onLanguageChange, course, onCourseChange }: ProfileScreenProps) {
  const [subTab, setSubTab] = useState<SubTab>('details');
  const [editing, setEditing] = useState<string | null>(null);
  const [saved, setSaved] = useState(false);

  const handleSave = () => {
    setEditing(null);
    setSaved(true);
    setTimeout(() => setSaved(false), 2200);
  };

  return (
    <div className="px-5 py-4 space-y-5 animate-fade-in">
      {/* Profile header */}
      <div className="bg-white rounded-3xl border border-slate-100 shadow-sm overflow-hidden">
        <div className="h-20 bg-gradient-to-r from-blue-600 via-blue-500 to-sky-400" />
        <div className="px-5 pb-5">
          <div className="flex items-end justify-between -mt-10">
            <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-amber-400 to-orange-500 flex items-center justify-center text-white text-2xl font-bold ring-4 ring-white shadow-lg">
              AS
            </div>
            <button
              onClick={() => setEditing(editing === null ? 'name' : null)}
              className="px-4 py-2 rounded-xl bg-blue-600 text-white text-sm font-semibold flex items-center gap-1.5 active:scale-95 transition-transform shadow-md shadow-blue-500/20 mb-1"
            >
              <Edit3 size={14} /> {editing ? 'Editing' : 'Edit'}
            </button>
          </div>
          <div className="mt-3">
            <h2 className="text-lg font-bold text-slate-900">Aarav Sharma</h2>
            <p className="text-sm text-slate-500">Form No: ALN-2026-04891</p>
            <div className="flex items-center gap-2 mt-2">
              <span className="text-[10px] font-semibold text-blue-600 bg-blue-50 px-2 py-0.5 rounded-full">JEE Advanced</span>
              <span className="text-[10px] font-semibold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-full">Active</span>
            </div>
          </div>
        </div>
      </div>

      {/* Secondary tabs */}
      <div className="flex gap-1 bg-slate-100 rounded-2xl p-1">
        {SUB_TABS.map((tab) => {
          const isActive = subTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setSubTab(tab.id)}
              className={`flex-1 py-2.5 rounded-xl text-sm font-semibold transition-all ${
                isActive ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500'
              }`}
            >
              {tab.label}
            </button>
          );
        })}
      </div>

      {/* Profile details tab */}
      {subTab === 'details' && (
        <div className="space-y-2.5 animate-fade-in">
          {PROFILE_DETAILS.map((field) => {
            const Icon = field.icon;
            const isEditing = editing === field.id && field.editable;
            const isLanguage = field.id === 'language';
            const isCourse = field.id === 'course';
            return (
              <div key={field.id} className="bg-white rounded-2xl p-3.5 border border-slate-100 shadow-sm">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-slate-100 flex items-center justify-center flex-shrink-0">
                    <Icon size={17} className="text-slate-600" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-[11px] text-slate-400">{field.label}</p>
                    {isEditing && !isLanguage ? (
                      <input
                        defaultValue={field.value}
                        autoFocus
                        className="w-full text-sm font-semibold text-slate-800 bg-slate-50 rounded-lg px-2 py-1 mt-0.5 outline-none border border-blue-200 focus:border-blue-400"
                      />
                    ) : isEditing && isLanguage ? (
                      <select
                        value={language}
                        onChange={(e) => onLanguageChange(e.target.value)}
                        className="w-full text-sm font-semibold text-slate-800 bg-slate-50 rounded-lg px-2 py-1 mt-0.5 outline-none border border-blue-200 focus:border-blue-400"
                      >
                        {LANGUAGES.map((lang) => (
                          <option key={lang} value={lang}>{lang}</option>
                        ))}
                      </select>
                    ) : isEditing && isCourse ? (
                      <select
                        value={course}
                        onChange={(e) => onCourseChange(e.target.value)}
                        className="w-full text-sm font-semibold text-slate-800 bg-slate-50 rounded-lg px-2 py-1 mt-0.5 outline-none border border-blue-200 focus:border-blue-400"
                      >
                        {COURSES.map((c) => (
                          <option key={c} value={c}>{c}</option>
                        ))}
                      </select>
                    ) : (
                      <p className="text-sm font-semibold text-slate-800 truncate">
                        {field.id === 'language' ? language : field.id === 'course' ? course : field.value}
                      </p>
                    )}
                  </div>
                  {field.editable && (
                    <button
                      onClick={() => setEditing(isEditing ? null : field.id)}
                      className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 transition-all active:scale-90 ${
                        isEditing ? 'bg-emerald-500 text-white' : 'text-slate-400 hover:bg-slate-100'
                      }`}
                    >
                      {isEditing ? <Check size={15} /> : <Edit3 size={14} />}
                    </button>
                  )}
                </div>
              </div>
            );
          })}

          {/* Save button when editing */}
          {editing && (
            <button
              onClick={handleSave}
              className="w-full py-3.5 rounded-2xl bg-blue-600 text-white font-semibold text-sm shadow-lg shadow-blue-500/25 active:scale-[0.98] transition-transform flex items-center justify-center gap-2"
            >
              <Check size={16} /> Save changes
            </button>
          )}
        </div>
      )}

      {/* Preferences tab */}
      {subTab === 'preferences' && (
        <div className="space-y-3 animate-fade-in">
          {/* Language selector */}
          <div className="bg-white rounded-2xl p-4 border border-slate-100 shadow-sm">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-9 h-9 rounded-xl bg-blue-50 flex items-center justify-center flex-shrink-0">
                <Languages size={17} className="text-blue-600" />
              </div>
              <div>
                <p className="text-sm font-semibold text-slate-800">Preferred Language</p>
                <p className="text-[11px] text-slate-400">App content & exam language</p>
              </div>
            </div>
            <div className="flex flex-wrap gap-2">
              {LANGUAGES.map((lang) => (
                <button
                  key={lang}
                  onClick={() => onLanguageChange(lang)}
                  className={`px-3 py-1.5 rounded-full text-xs font-medium transition-all ${
                    language === lang
                      ? 'bg-blue-600 text-white shadow-sm'
                      : 'bg-slate-50 text-slate-500 border border-slate-100'
                  }`}
                >
                  {lang}
                </button>
              ))}
            </div>
          </div>

          {/* Settings list */}
          <div className="bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden divide-y divide-slate-50">
            {SETTINGS.map((item) => {
              const Icon = item.icon;
              return (
                <button
                  key={item.id}
                  className="w-full flex items-center gap-3 p-3.5 active:bg-slate-50 transition-colors text-left"
                >
                  <div className="w-9 h-9 rounded-xl bg-slate-100 flex items-center justify-center flex-shrink-0">
                    <Icon size={17} className="text-slate-600" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-slate-700">{item.label}</p>
                    <p className="text-[11px] text-slate-400">{item.desc}</p>
                  </div>
                  <ChevronRight size={18} className="text-slate-300" />
                </button>
              );
            })}
          </div>

          <p className="text-center text-[11px] text-slate-400 pt-1">trivive v1.0.0</p>
        </div>
      )}

      {/* Toast */}
      {saved && (
        <div className="fixed bottom-36 left-1/2 -translate-x-1/2 z-50 animate-slide-up">
          <div className="bg-slate-900 text-white text-sm font-medium px-5 py-3 rounded-2xl shadow-xl flex items-center gap-2">
            <Check size={16} className="text-emerald-400" /> Profile updated
          </div>
        </div>
      )}
    </div>
  );
}
