import { useState } from 'react';
import {
  Wallet,
  TrendingDown,
  TrendingUp,
  Award,
  Gift,
  Calculator,
  Info,
  CheckCircle2,
  Lock,
  Sparkles,
} from 'lucide-react';
import type { StudentProfile } from '@/types';
import { calculateMeritScore, getScholarshipEligibility, claimScholarship } from '@/hooks/useStudentData';

interface StudiesScreenProps {
  data: StudentProfile;
  setData: (d: StudentProfile) => void;
}

export default function StudiesScreen({ data, setData }: StudiesScreenProps) {
  const [claimedToast, setClaimedToast] = useState(false);
  const [claimedAmount, setClaimedAmount] = useState(0);

  const meritScore = calculateMeritScore(data);
  const eligibility = getScholarshipEligibility(meritScore);
  const totalStudyFunds = data.studyExpenses.reduce((s, e) => s + e.fee, 0);
  const shortfall = Math.max(0, totalStudyFunds - data.walletBalance);
  const alreadyClaimed = data.claimedScholarshipLevels.includes(eligibility.amount);

  const handleClaim = () => {
    if (eligibility.amount === 0 || alreadyClaimed) return;
    setData(claimScholarship(data, eligibility.amount));
    setClaimedAmount(eligibility.amount);
    setClaimedToast(true);
    setTimeout(() => setClaimedToast(false), 3000);
  };

  // Study Now Pay Later simulation
  const olympiadFee = 2000;
  const availableWallet = data.walletBalance;
  const learningSupport = eligibility.amount;
  const familyContribution = Math.max(0, olympiadFee - availableWallet - learningSupport);

  return (
    <div className="px-5 py-4 space-y-5 animate-fade-in">
      {/* Balance card */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-blue-700 via-blue-600 to-indigo-600 p-5 shadow-xl shadow-blue-500/20">
        <div className="absolute -top-8 -right-8 w-32 h-32 rounded-full bg-white/10" />
        <div className="relative">
          <div className="flex items-center gap-2">
            <Wallet size={18} className="text-white" />
            <span className="text-white/80 text-xs font-semibold uppercase tracking-wide">Current Balance</span>
          </div>
          <p className="text-white text-3xl font-bold mt-2">₹{data.walletBalance.toLocaleString('en-IN')}</p>
        </div>
      </div>

      {/* Study funds required */}
      <div className="bg-white rounded-2xl p-4 border border-slate-100 shadow-sm">
        <h3 className="text-sm font-bold text-slate-700 mb-3">Total Study Funds Required</h3>
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs text-slate-500">Current Wallet</span>
            <span className="text-sm font-semibold text-slate-700">₹{data.walletBalance.toLocaleString('en-IN')}</span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-xs text-slate-500">Required</span>
            <span className="text-sm font-semibold text-slate-700">₹{totalStudyFunds.toLocaleString('en-IN')}</span>
          </div>
          <div className="flex items-center justify-between pt-2 border-t border-slate-50">
            <span className="text-xs font-semibold text-slate-600">Shortfall</span>
            <span className={`text-sm font-bold ${shortfall > 0 ? 'text-rose-600' : 'text-emerald-600'}`}>
              ₹{shortfall.toLocaleString('en-IN')}
            </span>
          </div>
        </div>
      </div>

      {/* Upcoming exams */}
      <div>
        <h3 className="text-base font-bold text-slate-900 mb-3">Upcoming Exams / Educational Needs</h3>
        <div className="space-y-2.5">
          {data.studyExpenses.map((exp) => (
            <div key={exp.id} className="bg-white rounded-2xl p-3.5 border border-slate-100 shadow-sm flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-blue-50 flex items-center justify-center flex-shrink-0">
                <TrendingDown size={18} className="text-blue-600" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold text-slate-800">{exp.title}</p>
                <p className="text-[11px] text-slate-400">Due: {exp.dueDate}</p>
              </div>
              <span className="text-sm font-bold text-slate-700">₹{exp.fee}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Merit scholarship */}
      <div className="bg-gradient-to-br from-emerald-50 to-teal-50 rounded-2xl p-4 border border-emerald-100">
        <div className="flex items-center gap-2 mb-3">
          <Award size={18} className="text-emerald-600" />
          <h3 className="text-sm font-bold text-slate-700">Merit Scholarship</h3>
        </div>

        {/* Merit score */}
        <div className="bg-white rounded-xl p-3.5 mb-3">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs text-slate-500">Merit Score</span>
            <span className="text-lg font-bold text-emerald-600">{meritScore} / 100</span>
          </div>
          <div className="h-2 rounded-full bg-slate-100 overflow-hidden">
            <div
              className="h-full rounded-full bg-gradient-to-r from-emerald-400 to-teal-500 transition-all"
              style={{ width: `${meritScore}%` }}
            />
          </div>
          <div className="mt-2 text-[11px] text-slate-400">
            40% quiz · 25% chapters · 20% streak · 15% XP
          </div>
        </div>

        {/* Eligibility */}
        <div className="flex items-center gap-2 mb-3">
          <Gift size={16} className={eligibility.amount > 0 ? 'text-emerald-600' : 'text-slate-400'} />
          <span className="text-sm font-semibold text-slate-700">{eligibility.label}</span>
        </div>

        <button
          onClick={handleClaim}
          disabled={eligibility.amount === 0 || alreadyClaimed}
          className={`w-full py-3 rounded-xl font-semibold text-sm flex items-center justify-center gap-2 transition-all ${
            eligibility.amount === 0 || alreadyClaimed
              ? 'bg-slate-200 text-slate-400'
              : 'bg-emerald-600 text-white shadow-lg shadow-emerald-500/25 active:scale-[0.98]'
          }`}
        >
          {alreadyClaimed ? (
            <>
              <CheckCircle2 size={16} /> Already claimed ₹{eligibility.amount}
            </>
          ) : eligibility.amount === 0 ? (
            <>
              <Lock size={16} /> Locked — keep learning
            </>
          ) : (
            <>
              <Sparkles size={16} /> Claim ₹{eligibility.amount} Demo Scholarship
            </>
          )}
        </button>

        <div className="flex items-start gap-1.5 mt-2.5">
          <Info size={12} className="text-slate-400 flex-shrink-0 mt-0.5" />
          <p className="text-[10px] text-slate-400 leading-relaxed">
            Demo scholarship simulation — no real money involved.
          </p>
        </div>
      </div>

      {/* Study Now Pay Later */}
      <div className="bg-white rounded-2xl p-4 border border-slate-100 shadow-sm">
        <div className="flex items-center gap-2 mb-3">
          <Calculator size={16} className="text-blue-600" />
          <h3 className="text-sm font-bold text-slate-700">Study Now, Pay Later (Simulator)</h3>
        </div>
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs text-slate-500">Olympiad Fee</span>
            <span className="text-sm font-semibold text-slate-700">₹{olympiad}</span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-xs text-slate-500">Available Wallet</span>
            <span className="text-sm font-semibold text-slate-700">₹{availableWallet}</span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-xs text-slate-500">Merit Score</span>
            <span className="text-sm font-semibold text-emerald-600">{meritScore}</span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-xs text-slate-500">Eligible Learning Support</span>
            <span className="text-sm font-semibold text-emerald-600">₹{learningSupport}</span>
          </div>
          <div className="flex items-center justify-between pt-2 border-t border-slate-50">
            <span className="text-xs font-semibold text-slate-600">Remaining Family Contribution</span>
            <span className={`text-sm font-bold ${familyContribution > 0 ? 'text-rose-600' : 'text-emerald-600'}`}>
              ₹{familyContribution}
            </span>
          </div>
        </div>
        <div className="flex items-start gap-1.5 mt-3">
          <Info size={12} className="text-slate-400 flex-shrink-0 mt-0.5" />
          <p className="text-[10px] text-slate-400 leading-relaxed">This is a simulation only.</p>
        </div>
      </div>

      {/* Toast */}
      {claimedToast && (
        <div className="fixed bottom-28 left-1/2 -translate-x-1/2 z-50 animate-slide-up">
          <div className="bg-slate-900 text-white text-sm font-medium px-5 py-3 rounded-2xl shadow-xl flex items-center gap-2">
            <TrendingUp size={16} className="text-emerald-400" /> ₹{claimedAmount} scholarship added to wallet!
          </div>
        </div>
      )}
    </div>
  );
}
