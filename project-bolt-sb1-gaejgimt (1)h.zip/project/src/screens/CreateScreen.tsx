import { useState } from 'react';
import { Brain, Dumbbell, TrendingUp, Flame, Plus, Check, Clock, Star } from 'lucide-react';

type Category = 'growth' | 'focus' | 'strength';

interface FoodItem {
  id: number;
  name: string;
  desc: string;
  price: string;
  calories: string;
  rating: number;
  available: boolean;
  tags: string[];
  color: string;
}

const CATEGORIES: { id: Category; label: string; icon: typeof Brain; color: string; bg: string }[] = [
  { id: 'growth', label: 'Growth', icon: TrendingUp, color: 'text-emerald-600', bg: 'bg-emerald-50' },
  { id: 'focus', label: 'Focus', icon: Brain, color: 'text-blue-600', bg: 'bg-blue-50' },
  { id: 'strength', label: 'Strength', icon: Dumbbell, color: 'text-orange-600', bg: 'bg-orange-50' },
];

const FOOD: Record<Category, FoodItem[]> = {
  growth: [
    { id: 1, name: 'Sprouts & Paneer Bowl', desc: 'Protein-rich moong sprouts with grilled paneer', price: '₹60', calories: '320 kcal', rating: 4.7, available: true, tags: ['High Protein', 'Iron'], color: 'from-emerald-400 to-teal-500' },
    { id: 2, name: 'Spinach Dal Rice', desc: 'Palak dal with brown rice and ghee', price: '₹45', calories: '410 kcal', rating: 4.5, available: true, tags: ['Iron', 'Fiber'], color: 'from-green-400 to-emerald-500' },
    { id: 3, name: 'Egg & Avocado Toast', desc: 'Whole wheat toast with boiled egg and avocado', price: '₹55', calories: '280 kcal', rating: 4.8, available: true, tags: ['Protein', 'Healthy Fat'], color: 'from-lime-400 to-green-500' },
    { id: 4, name: 'Chickpea Salad', desc: 'Chana salad with cucumber, tomato & lemon', price: '₹40', calories: '220 kcal', rating: 4.4, available: false, tags: ['Protein', 'Fiber'], color: 'from-emerald-400 to-green-500' },
  ],
  focus: [
    { id: 1, name: 'Almond & Walnut Mix', desc: 'A handful of soaked almonds and walnuts', price: '₹30', calories: '180 kcal', rating: 4.9, available: true, tags: ['Omega-3', 'Memory'], color: 'from-blue-400 to-indigo-500' },
    { id: 2, name: 'Dark Chocolate Oats', desc: 'Oats with 70% dark chocolate and banana', price: '₹50', calories: '340 kcal', rating: 4.6, available: true, tags: ['Antioxidant', 'Energy'], color: 'from-indigo-400 to-blue-500' },
    { id: 3, name: 'Green Tea & Makhana', desc: 'Roasted fox nuts with a cup of green tea', price: '₹35', calories: '120 kcal', rating: 4.5, available: true, tags: ['Antioxidant', 'Low Cal'], color: 'from-sky-400 to-blue-500' },
    { id: 4, name: 'Blueberry Yogurt', desc: 'Greek yogurt with fresh blueberries & seeds', price: '₹65', calories: '200 kcal', rating: 4.7, available: true, tags: ['Probiotic', 'Brain'], color: 'from-blue-400 to-cyan-500' },
  ],
  strength: [
    { id: 1, name: 'Chicken & Rice Plate', desc: 'Grilled chicken breast with jeera rice', price: '₹80', calories: '520 kcal', rating: 4.8, available: true, tags: ['High Protein', 'Carbs'], color: 'from-orange-400 to-red-500' },
    { id: 2, name: 'Peanut Butter Banana Shake', desc: 'Thick shake with peanut butter & banana', price: '₹55', calories: '380 kcal', rating: 4.7, available: true, tags: ['Protein', 'Energy'], color: 'from-amber-400 to-orange-500' },
    { id: 3, name: 'Soya Chaap Curry', desc: 'Protein-packed soya chaap in masala gravy', price: '₹60', calories: '440 kcal', rating: 4.5, available: true, tags: ['Plant Protein'], color: 'from-red-400 to-orange-500' },
    { id: 4, name: 'Boiled Egg Combo', desc: '4 boiled eggs with salt, pepper & toast', price: '₹45', calories: '300 kcal', rating: 4.6, available: false, tags: ['Protein', 'Quick'], color: 'from-orange-400 to-amber-500' },
  ],
};

export default function CreateScreen() {
  const [activeCat, setActiveCat] = useState<Category>('growth');
  const [cart, setCart] = useState<string[]>([]);
  const [ordered, setOrdered] = useState(false);

  const items = FOOD[activeCat];
  const activeCatObj = CATEGORIES.find((c) => c.id === activeCat)!;

  const toggleCart = (id: string) => {
    setCart((prev) => (prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]));
  };

  const handleOrder = () => {
    if (cart.length === 0) return;
    setOrdered(true);
    setCart([]);
    setTimeout(() => setOrdered(false), 2500);
  };

  return (
    <div className="px-5 py-4 space-y-5 animate-fade-in">
      {/* Hero banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-emerald-600 via-emerald-600 to-teal-500 p-5 shadow-xl shadow-emerald-500/20">
        <div className="absolute -top-8 -right-8 w-32 h-32 rounded-full bg-white/10" />
        <div className="relative">
          <h2 className="text-white text-lg font-bold leading-snug">Eat smart, study harder</h2>
          <p className="mt-1 text-emerald-100 text-sm">
            Canteen meals sorted by what your body needs — growth, focus, or strength.
          </p>
          <div className="flex items-center gap-4 mt-3">
            <div className="flex items-center gap-1.5 text-white/90 text-xs">
              <Clock size={13} /> Open 8 AM – 8 PM
            </div>
            <div className="flex items-center gap-1.5 text-white/90 text-xs">
              <Flame size={13} /> {items.length} items today
            </div>
          </div>
        </div>
      </div>

      {/* Category selector */}
      <div className="grid grid-cols-3 gap-3">
        {CATEGORIES.map((cat) => {
          const Icon = cat.icon;
          const isActive = activeCat === cat.id;
          return (
            <button
              key={cat.id}
              onClick={() => setActiveCat(cat.id)}
              className={`rounded-2xl p-3.5 border transition-all active:scale-95 ${
                isActive
                  ? 'bg-white border-emerald-200 shadow-md shadow-emerald-100'
                  : 'bg-white border-slate-100 shadow-sm opacity-70'
              }`}
            >
              <div className={`w-9 h-9 rounded-xl ${cat.bg} flex items-center justify-center mb-2`}>
                <Icon size={18} className={cat.color} />
              </div>
              <p className={`text-sm font-bold ${isActive ? 'text-slate-900' : 'text-slate-500'}`}>{cat.label}</p>
              <p className="text-[10px] text-slate-400 mt-0.5">{FOOD[cat.id].length} items</p>
            </button>
          );
        })}
      </div>

      {/* Food items */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-base font-bold text-slate-900">
            {activeCatObj.label} foods
          </h3>
          <span className="text-xs text-slate-400">Tap + to add to order</span>
        </div>
        <div className="space-y-3">
          {items.map((item) => {
            const inCart = cart.includes(`${activeCat}-${item.id}`);
            return (
              <div
                key={item.id}
                className="bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden"
              >
                <div className="flex">
                  <div className={`w-20 flex-shrink-0 bg-gradient-to-br ${item.color} flex items-center justify-center`}>
                    <span className="text-white text-[10px] font-bold uppercase rotate-[-90deg] whitespace-nowrap tracking-wide">
                      {activeCat}
                    </span>
                  </div>
                  <div className="flex-1 p-3.5">
                    <div className="flex items-start justify-between gap-2">
                      <div className="min-w-0">
                        <p className="text-sm font-semibold text-slate-800 truncate">{item.name}</p>
                        <p className="text-[11px] text-slate-400 mt-0.5 leading-snug">{item.desc}</p>
                      </div>
                      <button
                        onClick={() => toggleCart(`${activeCat}-${item.id}`)}
                        disabled={!item.available}
                        className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 transition-all active:scale-90 ${
                          !item.available
                            ? 'bg-slate-100 text-slate-300'
                            : inCart
                            ? 'bg-emerald-500 text-white'
                            : 'bg-emerald-50 text-emerald-600'
                        }`}
                      >
                        {inCart ? <Check size={16} /> : <Plus size={16} />}
                      </button>
                    </div>
                    <div className="flex items-center gap-2 mt-2 flex-wrap">
                      <span className="text-sm font-bold text-slate-900">{item.price}</span>
                      <span className="text-[11px] text-slate-400">{item.calories}</span>
                      <span className="flex items-center gap-0.5 text-[11px] text-slate-500">
                        <Star size={11} className="text-amber-400 fill-amber-400" /> {item.rating}
                      </span>
                      {!item.available && (
                        <span className="text-[10px] font-semibold text-rose-500 bg-rose-50 px-2 py-0.5 rounded-full">
                          Out of stock
                        </span>
                      )}
                    </div>
                    <div className="flex gap-1.5 mt-2">
                      {item.tags.map((tag) => (
                        <span key={tag} className="text-[10px] font-medium text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full">
                          {tag}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Order bar */}
      {cart.length > 0 && (
        <div className="fixed bottom-20 left-1/2 -translate-x-1/2 w-full max-w-md px-5 z-40 animate-slide-up">
          <button
            onClick={handleOrder}
            className="w-full bg-emerald-600 text-white py-3.5 rounded-2xl font-semibold text-sm shadow-xl shadow-emerald-500/30 flex items-center justify-center gap-2 active:scale-[0.98] transition-transform"
          >
            Place order · {cart.length} item{cart.length > 1 ? 's' : ''}
          </button>
        </div>
      )}

      {/* Toast */}
      {ordered && (
        <div className="fixed bottom-36 left-1/2 -translate-x-1/2 z-50 animate-slide-up">
          <div className="bg-slate-900 text-white text-sm font-medium px-5 py-3 rounded-2xl shadow-xl flex items-center gap-2">
            <Check size={16} className="text-emerald-400" /> Order placed! Pick up at counter 2.
          </div>
        </div>
      )}
    </div>
  );
}
