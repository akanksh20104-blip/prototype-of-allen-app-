import { useState } from 'react';
import {
  Building2,
  Wifi,
  Lightbulb,
  Droplets,
  Wind,
  Wrench,
  Send,
  Check,
  AlertCircle,
  Clock,
} from 'lucide-react';

type SubTab = 'classroom' | 'infrastructure';

interface Complaint {
  id: number;
  title: string;
  location: string;
  status: 'Pending' | 'In Progress' | 'Resolved';
  time: string;
  category: string;
}

const SUB_TABS: { id: SubTab; label: string; icon: typeof Building2 }[] = [
  { id: 'classroom', label: 'Classroom', icon: Building2 },
  { id: 'infrastructure', label: 'Infrastructure', icon: Wrench },
];

const COMPLAINT_TYPES: Record<SubTab, { id: string; label: string; icon: typeof Wifi; color: string; bg: string }[]> = {
  classroom: [
    { id: 'fan', label: 'Fan / AC not working', icon: Wind, color: 'text-blue-600', bg: 'bg-blue-50' },
    { id: 'light', label: 'Light / Tube light issue', icon: Lightbulb, color: 'text-amber-600', bg: 'bg-amber-50' },
    { id: 'wifi', label: 'Wi-Fi / Projector problem', icon: Wifi, color: 'text-emerald-600', bg: 'bg-emerald-50' },
    { id: 'bench', label: 'Broken bench / desk', icon: Wrench, color: 'text-rose-600', bg: 'bg-rose-50' },
  ],
  infrastructure: [
    { id: 'water', label: 'Drinking water issue', icon: Droplets, color: 'text-cyan-600', bg: 'bg-cyan-50' },
    { id: 'toilet', label: 'Washroom / toilet problem', icon: Wrench, color: 'text-violet-600', bg: 'bg-violet-50' },
    { id: 'electric', label: 'Electrical / wiring fault', icon: Lightbulb, color: 'text-orange-600', bg: 'bg-orange-50' },
    { id: 'building', label: 'Wall / ceiling damage', icon: Building2, color: 'text-slate-600', bg: 'bg-slate-100' },
  ],
};

const RECENT_COMPLAINTS: Record<SubTab, Complaint[]> = {
  classroom: [
    { id: 1, title: 'Projector not working in Room 204', location: 'Block A · Room 204', status: 'In Progress', time: '2h ago', category: 'Wi-Fi / Projector' },
    { id: 2, title: 'Ceiling fan wobbling in Lab 3', location: 'Block B · Lab 3', status: 'Pending', time: '5h ago', category: 'Fan / AC' },
    { id: 3, title: 'Tube light flickering in Room 112', location: 'Block A · Room 112', status: 'Resolved', time: '1d ago', category: 'Light' },
  ],
  infrastructure: [
    { id: 1, title: 'Water cooler leaking near canteen', location: 'Canteen Block', status: 'In Progress', time: '3h ago', category: 'Drinking Water' },
    { id: 2, title: 'Washroom tap broken — Block C ground', location: 'Block C · Ground Floor', status: 'Pending', time: '6h ago', category: 'Washroom' },
    { id: 3, title: 'Exposed wiring near staircase', location: 'Block A · Staircase 2', status: 'Resolved', time: '2d ago', category: 'Electrical' },
  ],
};

const STATUS_STYLES: Record<Complaint['status'], string> = {
  Pending: 'bg-amber-50 text-amber-600',
  'In Progress': 'bg-blue-50 text-blue-600',
  Resolved: 'bg-emerald-50 text-emerald-600',
};

export default function ActivityScreen() {
  const [subTab, setSubTab] = useState<SubTab>('classroom');
  const [selectedType, setSelectedType] = useState<string | null>(null);
  const [location, setLocation] = useState('');
  const [details, setDetails] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const complaintTypes = COMPLAINT_TYPES[subTab];
  const recent = RECENT_COMPLAINTS[subTab];

  const handleSubmit = () => {
    if (!selectedType || !location.trim()) return;
    setSubmitted(true);
    setSelectedType(null);
    setLocation('');
    setDetails('');
    setTimeout(() => setSubmitted(false), 2800);
  };

  return (
    <div className="px-5 py-4 space-y-5 animate-fade-in">
      {/* Secondary tabs */}
      <div className="flex gap-2 bg-slate-100 rounded-2xl p-1">
        {SUB_TABS.map((tab) => {
          const Icon = tab.icon;
          const isActive = subTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => {
                setSubTab(tab.id);
                setSelectedType(null);
              }}
              className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl text-sm font-semibold transition-all ${
                isActive ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500'
              }`}
            >
              <Icon size={16} />
              {tab.label}
            </button>
          );
        })}
      </div>

      {/* New complaint form */}
      <div className="bg-white rounded-3xl border border-slate-100 shadow-sm p-4 space-y-4">
        <div>
          <h3 className="text-base font-bold text-slate-900 mb-1">File a new complaint</h3>
          <p className="text-xs text-slate-400">Select the issue type and tell us where it is.</p>
        </div>

        {/* Issue type grid */}
        <div className="grid grid-cols-2 gap-3">
          {complaintTypes.map((type) => {
            const Icon = type.icon;
            const isSelected = selectedType === type.id;
            return (
              <button
                key={type.id}
                onClick={() => setSelectedType(type.id)}
                className={`flex items-center gap-2.5 p-3 rounded-2xl border text-left transition-all active:scale-95 ${
                  isSelected
                    ? 'border-blue-500 bg-blue-50 ring-1 ring-blue-200'
                    : 'border-slate-100 bg-slate-50'
                }`}
              >
                <div className={`w-9 h-9 rounded-xl ${type.bg} flex items-center justify-center flex-shrink-0`}>
                  <Icon size={17} className={type.color} />
                </div>
                <span className={`text-xs font-medium leading-snug ${isSelected ? 'text-slate-900' : 'text-slate-600'}`}>
                  {type.label}
                </span>
              </button>
            );
          })}
        </div>

        {/* Location input */}
        <div>
          <label className="text-xs font-semibold text-slate-500 mb-1.5 block">Location</label>
          <input
            value={location}
            onChange={(e) => setLocation(e.target.value)}
            placeholder="e.g. Block A, Room 204"
            className="w-full bg-slate-50 rounded-xl px-4 py-3 text-sm text-slate-700 placeholder-slate-400 outline-none border border-slate-100 focus:border-blue-300 focus:bg-white transition-colors"
          />
        </div>

        {/* Details */}
        <div>
          <label className="text-xs font-semibold text-slate-500 mb-1.5 block">Details (optional)</label>
          <textarea
            value={details}
            onChange={(e) => setDetails(e.target.value)}
            placeholder="Describe the issue..."
            rows={2}
            className="w-full bg-slate-50 rounded-xl px-4 py-3 text-sm text-slate-700 placeholder-slate-400 outline-none border border-slate-100 focus:border-blue-300 focus:bg-white transition-colors resize-none"
          />
        </div>

        {/* Submit */}
        <button
          onClick={handleSubmit}
          disabled={!selectedType || !location.trim()}
          className={`w-full py-3.5 rounded-2xl font-semibold text-sm flex items-center justify-center gap-2 transition-all ${
            selectedType && location.trim()
              ? 'bg-blue-600 text-white shadow-lg shadow-blue-500/25 active:scale-[0.98]'
              : 'bg-slate-200 text-slate-400'
          }`}
        >
          <Send size={16} /> Submit complaint
        </button>
      </div>

      {/* Recent complaints */}
      <div>
        <h3 className="text-base font-bold text-slate-900 mb-3">Recent complaints</h3>
        <div className="space-y-2.5">
          {recent.map((c) => (
            <div key={c.id} className="bg-white rounded-2xl p-3.5 border border-slate-100 shadow-sm">
              <div className="flex items-start justify-between gap-2 mb-2">
                <p className="text-sm font-semibold text-slate-800 leading-snug">{c.title}</p>
                <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full flex-shrink-0 ${STATUS_STYLES[c.status]}`}>
                  {c.status}
                </span>
              </div>
              <div className="flex items-center gap-3 text-[11px] text-slate-400">
                <span className="flex items-center gap-1">
                  <Building2 size={11} /> {c.location}
                </span>
                <span className="flex items-center gap-1">
                  <Clock size={11} /> {c.time}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Toast */}
      {submitted && (
        <div className="fixed bottom-36 left-1/2 -translate-x-1/2 z-50 animate-slide-up">
          <div className="bg-slate-900 text-white text-sm font-medium px-5 py-3 rounded-2xl shadow-xl flex items-center gap-2">
            <Check size={16} className="text-emerald-400" /> Complaint registered. We'll follow up soon.
          </div>
        </div>
      )}

      {/* Info banner */}
      <div className="flex items-start gap-2.5 bg-blue-50 rounded-2xl p-3.5 border border-blue-100">
        <AlertCircle size={18} className="text-blue-600 flex-shrink-0 mt-0.5" />
        <p className="text-xs text-blue-700 leading-relaxed">
          Complaints are routed to the maintenance cell. Expect a response within 24 hours for classroom issues and 48 hours for infrastructure.
        </p>
      </div>
    </div>
  );
}
